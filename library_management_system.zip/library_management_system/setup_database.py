import mysql.connector
from config import Config
import getpass

def create_database():
    # Connect to MySQL without selecting database
    conn = mysql.connector.connect(
        host=Config.MYSQL_HOST,
        user=Config.MYSQL_USER,
        password=Config.MYSQL_PASSWORD,
        port=Config.MYSQL_PORT
    )
    cursor = conn.cursor()
    
    # Create database
    print(f"Creating database '{Config.MYSQL_DB}'...")
    cursor.execute(f"CREATE DATABASE IF NOT EXISTS {Config.MYSQL_DB}")
    print("Database created successfully!")
    
    cursor.close()
    conn.close()

def create_admin_user():
    from app import create_app
    from models.user import User
    
    app = create_app()
    with app.app_context():
        # Check if admin exists
        admin = User.get_by_username('admin')
        
        if not admin:
            print("\nCreating admin user...")
            print("=" * 40)
            
            username = 'admin'
            email = 'admin@library.com'
            
            # Get password securely
            while True:
                password = getpass.getpass("Enter admin password: ")
                confirm = getpass.getpass("Confirm password: ")
                
                if password == confirm:
                    if len(password) >= 8:
                        break
                    else:
                        print("Password must be at least 8 characters long!")
                else:
                    print("Passwords don't match!")
            
            try:
                admin = User.create(
                    username=username,
                    email=email,
                    password=password,
                    full_name='Administrator',
                    role='admin'
                )
                print(f"✓ Admin user created successfully!")
                print(f"  Username: {username}")
                print(f"  Email: {email}")
            
            except Exception as e:
                print(f"✗ Error creating admin: {str(e)}")
        
        else:
            print("Admin user already exists!")

def populate_sample_data():
    from app import create_app
    from models.book import Book
    from models.database import mysql
    
    app = create_app()
    with app.app_context():
        cursor = mysql.connection.cursor()
        
        # Check if books exist
        cursor.execute('SELECT COUNT(*) FROM books')
        count = cursor.fetchone()[0]
        
        if count == 0:
            print("\nAdding sample books...")
            
            sample_books = [
                ('9780140283334', 'To Kill a Mockingbird', 'Harper Lee', 'Penguin Books', 1960, 'Fiction', 5, 3.99),
                ('9780743273565', 'The Great Gatsby', 'F. Scott Fitzgerald', 'Scribner', 1925, 'Fiction', 3, 2.99),
                ('9780547928227', 'The Hobbit', 'J.R.R. Tolkien', 'Houghton Mifflin', 1937, 'Fantasy', 4, 4.99),
                ('9780439023481', 'The Hunger Games', 'Suzanne Collins', 'Scholastic', 2008, 'Science Fiction', 6, 5.99),
                ('9781408855652', 'Harry Potter and the Philosopher\'s Stone', 'J.K. Rowling', 'Bloomsbury', 1997, 'Fantasy', 10, 6.99),
                ('9780061120084', '1984', 'George Orwell', 'Secker & Warburg', 1949, 'Dystopian', 4, 3.49),
                ('9781451673319', 'Fahrenheit 451', 'Ray Bradbury', 'Simon & Schuster', 1953, 'Dystopian', 3, 3.29),
                ('9780141187761', 'Animal Farm', 'George Orwell', 'Penguin Books', 1945, 'Political Satire', 5, 2.99),
                ('9780141439518', 'Pride and Prejudice', 'Jane Austen', 'Penguin Classics', 1813, 'Romance', 4, 3.49),
                ('9780316769174', 'The Catcher in the Rye', 'J.D. Salinger', 'Little, Brown', 1951, 'Fiction', 3, 3.79),
            ]
            
            for isbn, title, author, publisher, year, category, copies, price in sample_books:
                Book.create(
                    isbn=isbn,
                    title=title,
                    author=author,
                    publisher=publisher,
                    publication_year=year,
                    category=category,
                    total_copies=copies,
                    available_copies=copies,
                    price=price,
                    description=f"A classic book: {title} by {author}."
                )
            
            print(f"✓ Added {len(sample_books)} sample books!")
        
        else:
            print(f"Database already contains {count} books.")
        
        cursor.close()

if __name__ == '__main__':
    print("Library Management System - Database Setup")
    print("=" * 50)
    
    try:
        create_database()
        create_admin_user()
        populate_sample_data()
        
        print("\n" + "=" * 50)
        print("Setup completed successfully!")
        print("\nTo run the application:")
        print("1. pip install -r requirements.txt")
        print("2. python app.py")
        print("3. Open http://localhost:5000 in your browser")
        print("\nAdmin login:")
        print("  Username: admin")
        print("  Password: [what you set during setup]")
    
    except Exception as e:
        print(f"\n✗ Error during setup: {str(e)}")
        print("\nPlease check:")
        print("1. MySQL is running")
        print("2. MySQL credentials in config.py are correct")
        print("3. You have proper privileges")