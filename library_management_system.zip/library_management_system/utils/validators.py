import re
from datetime import datetime

def validate_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_password(password):
    # At least 8 characters, contains uppercase, lowercase and numbers
    if len(password) < 8:
        return False
    if not re.search(r'[A-Z]', password):
        return False
    if not re.search(r'[a-z]', password):
        return False
    if not re.search(r'\d', password):
        return False
    return True

def validate_isbn(isbn):
    # Simple ISBN validation (supports ISBN-10 and ISBN-13)
    isbn = isbn.replace('-', '').replace(' ', '')
    
    if len(isbn) == 10:
        # Validate ISBN-10
        if not re.match(r'^\d{9}[\dX]$', isbn):
            return False
        return True
    elif len(isbn) == 13:
        # Validate ISBN-13
        if not re.match(r'^\d{13}$', isbn):
            return False
        return True
    else:
        return False

def validate_phone(phone):
    # Validate Indian phone numbers
    pattern = r'^[6-9]\d{9}$'
    return re.match(pattern, phone) is not None

def validate_date(date_str):
    try:
        datetime.strptime(date_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False

def sanitize_input(text):
    # Basic sanitization for SQL injection prevention
    # (Note: Using parameterized queries is the real protection)
    if not text:
        return ''
    
    # Remove potentially dangerous characters
    text = str(text)
    text = text.replace(';', '')
    text = text.replace('--', '')
    text = text.replace('/*', '')
    text = text.replace('*/', '')
    text = text.replace('=', '')
    text = text.replace('<', '')
    text = text.replace('>', '')
    
    return text.strip()