from datetime import datetime, timedelta
from models.database import mysql

def calculate_due_date(issue_date, days=14):
    return issue_date + timedelta(days=days)

def calculate_fine(due_date, return_date, fine_per_day=10):
    if return_date <= due_date:
        return 0
    
    days_overdue = (return_date - due_date).days
    return days_overdue * fine_per_day

def format_date(date_obj):
    if not date_obj:
        return ''
    if isinstance(date_obj, str):
        return date_obj
    return date_obj.strftime('%d %b %Y')

def format_datetime(datetime_obj):
    if not datetime_obj:
        return ''
    return datetime_obj.strftime('%d %b %Y %I:%M %p')

def get_setting(key, default=None):
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT setting_value FROM settings WHERE setting_key = %s', (key,))
    result = cursor.fetchone()
    cursor.close()
    
    if result:
        return result[0]
    return default

def update_setting(key, value):
    cursor = mysql.connection.cursor()
    cursor.execute('''
        INSERT INTO settings (setting_key, setting_value) 
        VALUES (%s, %s)
        ON DUPLICATE KEY UPDATE setting_value = %s
    ''', (key, value, value))
    mysql.connection.commit()
    cursor.close()

def paginate(query, page, per_page):
    offset = (page - 1) * per_page
    return query.limit(per_page).offset(offset)