from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from models.database import mysql
from datetime import datetime

class User(UserMixin):
    def __init__(self, id, username, email, password_hash, full_name, role, 
                 phone=None, address=None, is_active=True, created_at=None):
        self.id = id
        self.username = username
        self.email = email
        self.password_hash = password_hash
        self.full_name = full_name
        self.role = role
        self.phone = phone
        self.address = address
        self.is_active = is_active
        self.created_at = created_at
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    @staticmethod
    def get_by_id(user_id):
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM users WHERE id = %s', (user_id,))
        user_data = cursor.fetchone()
        cursor.close()
        
        if user_data:
            return User(*user_data)
        return None
    
    @staticmethod
    def get_by_username(username):
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
        user_data = cursor.fetchone()
        cursor.close()
        
        if user_data:
            return User(*user_data)
        return None
    
    @staticmethod
    def get_by_email(email):
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
        user_data = cursor.fetchone()
        cursor.close()
        
        if user_data:
            return User(*user_data)
        return None
    
    @staticmethod
    def create(username, email, password, full_name, role='user', phone=None, address=None):
        password_hash = generate_password_hash(password)
        cursor = mysql.connection.cursor()
        
        cursor.execute('''
            INSERT INTO users (username, email, password_hash, full_name, role, phone, address)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        ''', (username, email, password_hash, full_name, role, phone, address))
        
        mysql.connection.commit()
        user_id = cursor.lastrowid
        cursor.close()
        
        return User.get_by_id(user_id)
    
    def update(self, **kwargs):
        cursor = mysql.connection.cursor()
        
        # Build update query dynamically
        updates = []
        values = []
        
        for key, value in kwargs.items():
            if key == 'password':
                value = generate_password_hash(value)
                key = 'password_hash'
            updates.append(f"{key} = %s")
            values.append(value)
        
        if updates:
            values.append(self.id)
            query = f"UPDATE users SET {', '.join(updates)} WHERE id = %s"
            cursor.execute(query, values)
            mysql.connection.commit()
        
        cursor.close()
    
    def delete(self):
        cursor = mysql.connection.cursor()
        cursor.execute('DELETE FROM users WHERE id = %s', (self.id,))
        mysql.connection.commit()
        cursor.close()
    
    @staticmethod
    def get_all(limit=100, offset=0):
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM users ORDER BY created_at DESC LIMIT %s OFFSET %s', (limit, offset))
        users_data = cursor.fetchall()
        cursor.close()
        
        return [User(*data) for data in users_data]
    
    @staticmethod
    def search(query):
        cursor = mysql.connection.cursor()
        search_pattern = f"%{query}%"
        cursor.execute('''
            SELECT * FROM users 
            WHERE username LIKE %s OR email LIKE %s OR full_name LIKE %s
            ORDER BY created_at DESC
        ''', (search_pattern, search_pattern, search_pattern))
        users_data = cursor.fetchall()
        cursor.close()
        
        return [User(*data) for data in users_data]
    
    @staticmethod
    def count():
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT COUNT(*) FROM users')
        count = cursor.fetchone()[0]
        cursor.close()
        return count