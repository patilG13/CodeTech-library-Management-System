from models.database import mysql
from datetime import datetime

class Book:
    def __init__(self, id, isbn, title, author, publisher=None, publication_year=None,
                 category=None, total_copies=1, available_copies=1, price=None,
                 description=None, cover_image=None, created_at=None):
        self.id = id
        self.isbn = isbn
        self.title = title
        self.author = author
        self.publisher = publisher
        self.publication_year = publication_year
        self.category = category
        self.total_copies = total_copies
        self.available_copies = available_copies
        self.price = price
        self.description = description
        self.cover_image = cover_image
        self.created_at = created_at
    
    @staticmethod
    def get_by_id(book_id):
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM books WHERE id = %s', (book_id,))
        book_data = cursor.fetchone()
        cursor.close()
        
        if book_data:
            return Book(*book_data)
        return None
    
    @staticmethod
    def get_by_isbn(isbn):
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM books WHERE isbn = %s', (isbn,))
        book_data = cursor.fetchone()
        cursor.close()
        
        if book_data:
            return Book(*book_data)
        return None
    
    @staticmethod
    def create(isbn, title, author, **kwargs):
        cursor = mysql.connection.cursor()
        
        # Set default values
        defaults = {
            'publisher': None,
            'publication_year': None,
            'category': None,
            'total_copies': 1,
            'available_copies': 1,
            'price': None,
            'description': None,
            'cover_image': None
        }
        defaults.update(kwargs)
        
        cursor.execute('''
            INSERT INTO books (isbn, title, author, publisher, publication_year, 
                            category, total_copies, available_copies, price, 
                            description, cover_image)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ''', (isbn, title, author, defaults['publisher'], defaults['publication_year'],
              defaults['category'], defaults['total_copies'], defaults['available_copies'],
              defaults['price'], defaults['description'], defaults['cover_image']))
        
        mysql.connection.commit()
        book_id = cursor.lastrowid
        cursor.close()
        
        return Book.get_by_id(book_id)
    
    def update(self, **kwargs):
        cursor = mysql.connection.cursor()
        
        # Build update query dynamically
        updates = []
        values = []
        
        for key, value in kwargs.items():
            updates.append(f"{key} = %s")
            values.append(value)
        
        if updates:
            values.append(self.id)
            query = f"UPDATE books SET {', '.join(updates)} WHERE id = %s"
            cursor.execute(query, values)
            mysql.connection.commit()
        
        cursor.close()
    
    def delete(self):
        cursor = mysql.connection.cursor()
        cursor.execute('DELETE FROM books WHERE id = %s', (self.id,))
        mysql.connection.commit()
        cursor.close()
    
    @staticmethod
    def get_all(limit=100, offset=0, available_only=False):
        cursor = mysql.connection.cursor()
        
        if available_only:
            cursor.execute('''
                SELECT * FROM books 
                WHERE available_copies > 0 
                ORDER BY title LIMIT %s OFFSET %s
            ''', (limit, offset))
        else:
            cursor.execute('SELECT * FROM books ORDER BY title LIMIT %s OFFSET %s', (limit, offset))
        
        books_data = cursor.fetchall()
        cursor.close()
        
        return [Book(*data) for data in books_data]
    
    @staticmethod
    def search(query, field='all'):
        cursor = mysql.connection.cursor()
        search_pattern = f"%{query}%"
        
        if field == 'title':
            cursor.execute('SELECT * FROM books WHERE title LIKE %s ORDER BY title', (search_pattern,))
        elif field == 'author':
            cursor.execute('SELECT * FROM books WHERE author LIKE %s ORDER BY author', (search_pattern,))
        elif field == 'isbn':
            cursor.execute('SELECT * FROM books WHERE isbn LIKE %s', (search_pattern,))
        elif field == 'category':
            cursor.execute('SELECT * FROM books WHERE category LIKE %s ORDER BY category', (search_pattern,))
        else:
            cursor.execute('''
                SELECT * FROM books 
                WHERE title LIKE %s OR author LIKE %s OR isbn LIKE %s OR category LIKE %s
                ORDER BY title
            ''', (search_pattern, search_pattern, search_pattern, search_pattern))
        
        books_data = cursor.fetchall()
        cursor.close()
        
        return [Book(*data) for data in books_data]
    
    @staticmethod
    def count():
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT COUNT(*) FROM books')
        count = cursor.fetchone()[0]
        cursor.close()
        return count
    
    @staticmethod
    def get_categories():
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT DISTINCT category FROM books WHERE category IS NOT NULL ORDER BY category')
        categories = [row[0] for row in cursor.fetchall()]
        cursor.close()
        return categories