from models.database import mysql
from datetime import datetime, timedelta
from models.user import User
from models.book import Book

class Transaction:
    def __init__(self, id, user_id, book_id, issue_date, due_date, return_date=None,
                 status='issued', fine_amount=0, fine_paid=False, created_at=None):
        self.id = id
        self.user_id = user_id
        self.book_id = book_id
        self.issue_date = issue_date
        self.due_date = due_date
        self.return_date = return_date
        self.status = status
        self.fine_amount = fine_amount
        self.fine_paid = fine_paid
        self.created_at = created_at
    
    @staticmethod
    def get_by_id(transaction_id):
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM transactions WHERE id = %s', (transaction_id,))
        transaction_data = cursor.fetchone()
        cursor.close()
        
        if transaction_data:
            return Transaction(*transaction_data)
        return None
    
    @staticmethod
    def issue_book(user_id, book_id, max_days=14):
        # Check if book is available
        book = Book.get_by_id(book_id)
        if not book or book.available_copies <= 0:
            return None, "Book is not available"
        
        # Check if user has reached borrow limit
        cursor = mysql.connection.cursor()
        cursor.execute('''
            SELECT COUNT(*) FROM transactions 
            WHERE user_id = %s AND status IN ('issued', 'overdue')
        ''', (user_id,))
        active_borrows = cursor.fetchone()[0]
        
        if active_borrows >= 3:  # Max books per user
            cursor.close()
            return None, "Maximum borrow limit reached"
        
        # Calculate dates
        issue_date = datetime.now().date()
        due_date = issue_date + timedelta(days=max_days)
        
        # Create transaction
        cursor.execute('''
            INSERT INTO transactions (user_id, book_id, issue_date, due_date, status)
            VALUES (%s, %s, %s, %s, 'issued')
        ''', (user_id, book_id, issue_date, due_date))
        
        transaction_id = cursor.lastrowid
        
        # Update book availability
        cursor.execute('''
            UPDATE books SET available_copies = available_copies - 1 
            WHERE id = %s
        ''', (book_id,))
        
        mysql.connection.commit()
        cursor.close()
        
        return Transaction.get_by_id(transaction_id), "Book issued successfully"
    
    @staticmethod
    def return_book(transaction_id):
        cursor = mysql.connection.cursor()
        
        # Get transaction details
        cursor.execute('SELECT * FROM transactions WHERE id = %s', (transaction_id,))
        transaction_data = cursor.fetchone()
        
        if not transaction_data:
            cursor.close()
            return None, "Transaction not found"
        
        transaction = Transaction(*transaction_data)
        
        # Check if already returned
        if transaction.status == 'returned':
            cursor.close()
            return transaction, "Book already returned"
        
        # Calculate fine if any
        return_date = datetime.now().date()
        fine_amount = 0
        
        if return_date > transaction.due_date:
            days_overdue = (return_date - transaction.due_date).days
            cursor.execute('SELECT setting_value FROM settings WHERE setting_key = "fine_per_day"')
            fine_per_day = float(cursor.fetchone()[0] or 10)
            fine_amount = days_overdue * fine_per_day
        
        # Update transaction
        cursor.execute('''
            UPDATE transactions 
            SET return_date = %s, status = 'returned', fine_amount = %s
            WHERE id = %s
        ''', (return_date, fine_amount, transaction_id))
        
        # Update book availability
        cursor.execute('''
            UPDATE books SET available_copies = available_copies + 1 
            WHERE id = %s
        ''', (transaction.book_id,))
        
        # Create fine record if applicable
        if fine_amount > 0:
            cursor.execute('''
                INSERT INTO fines (transaction_id, user_id, amount)
                VALUES (%s, %s, %s)
            ''', (transaction_id, transaction.user_id, fine_amount))
        
        mysql.connection.commit()
        cursor.close()
        
        return Transaction.get_by_id(transaction_id), f"Book returned. Fine: ₹{fine_amount}" if fine_amount > 0 else "Book returned successfully"
    
    @staticmethod
    def get_user_transactions(user_id, status=None):
        cursor = mysql.connection.cursor()
        
        if status:
            cursor.execute('''
                SELECT t.*, b.title, b.author 
                FROM transactions t
                JOIN books b ON t.book_id = b.id
                WHERE t.user_id = %s AND t.status = %s
                ORDER BY t.issue_date DESC
            ''', (user_id, status))
        else:
            cursor.execute('''
                SELECT t.*, b.title, b.author 
                FROM transactions t
                JOIN books b ON t.book_id = b.id
                WHERE t.user_id = %s
                ORDER BY t.issue_date DESC
            ''', (user_id,))
        
        transactions = cursor.fetchall()
        cursor.close()
        
        return transactions
    
    @staticmethod
    def get_all_transactions(limit=100, offset=0):
        cursor = mysql.connection.cursor()
        cursor.execute('''
            SELECT t.*, u.username, u.full_name, b.title, b.isbn
            FROM transactions t
            JOIN users u ON t.user_id = u.id
            JOIN books b ON t.book_id = b.id
            ORDER BY t.created_at DESC
            LIMIT %s OFFSET %s
        ''', (limit, offset))
        transactions = cursor.fetchall()
        cursor.close()
        
        return transactions
    
    @staticmethod
    def get_overdue_transactions():
        cursor = mysql.connection.cursor()
        today = datetime.now().date()
        
        cursor.execute('''
            UPDATE transactions 
            SET status = 'overdue' 
            WHERE due_date < %s AND status = 'issued'
        ''', (today,))
        
        cursor.execute('''
            SELECT t.*, u.username, u.full_name, b.title, b.isbn
            FROM transactions t
            JOIN users u ON t.user_id = u.id
            JOIN books b ON t.book_id = b.id
            WHERE t.status = 'overdue'
            ORDER BY t.due_date
        ''')
        
        overdue_transactions = cursor.fetchall()
        mysql.connection.commit()
        cursor.close()
        
        return overdue_transactions
    
    @staticmethod
    def calculate_fine(transaction_id):
        transaction = Transaction.get_by_id(transaction_id)
        if not transaction or transaction.status == 'returned':
            return 0
        
        today = datetime.now().date()
        if today <= transaction.due_date:
            return 0
        
        days_overdue = (today - transaction.due_date).days
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT setting_value FROM settings WHERE setting_key = "fine_per_day"')
        fine_per_day = float(cursor.fetchone()[0] or 10)
        cursor.close()
        
        return days_overdue * fine_per_day