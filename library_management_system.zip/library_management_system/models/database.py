from flask_mysqldb import MySQL
from flask_login import LoginManager

mysql = MySQL()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'info'

def init_db(app):
    mysql.init_app(app)
    login_manager.init_app(app)
    
    # Create tables if they don't exist
    with app.app_context():
        cursor = mysql.connection.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                role ENUM('admin', 'user') DEFAULT 'user',
                phone VARCHAR(15),
                address TEXT,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        ''')
        
        # Books table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS books (
                id INT AUTO_INCREMENT PRIMARY KEY,
                isbn VARCHAR(20) UNIQUE NOT NULL,
                title VARCHAR(200) NOT NULL,
                author VARCHAR(100) NOT NULL,
                publisher VARCHAR(100),
                publication_year INT,
                category VARCHAR(50),
                total_copies INT DEFAULT 1,
                available_copies INT DEFAULT 1,
                price DECIMAL(10, 2),
                description TEXT,
                cover_image VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        ''')
        
        # Transactions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                book_id INT NOT NULL,
                issue_date DATE NOT NULL,
                due_date DATE NOT NULL,
                return_date DATE,
                status ENUM('issued', 'returned', 'overdue') DEFAULT 'issued',
                fine_amount DECIMAL(10, 2) DEFAULT 0,
                fine_paid BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
                INDEX idx_user_id (user_id),
                INDEX idx_book_id (book_id),
                INDEX idx_status (status)
            )
        ''')
        
        # Fines table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS fines (
                id INT AUTO_INCREMENT PRIMARY KEY,
                transaction_id INT NOT NULL,
                user_id INT NOT NULL,
                amount DECIMAL(10, 2) NOT NULL,
                paid BOOLEAN DEFAULT FALSE,
                paid_date DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ''')
        
        # Settings table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                setting_key VARCHAR(50) UNIQUE NOT NULL,
                setting_value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        ''')
        
        # Insert default settings
        cursor.execute('''
            INSERT IGNORE INTO settings (setting_key, setting_value)
            VALUES 
                ('fine_per_day', '10'),
                ('max_borrow_days', '14'),
                ('max_books_per_user', '3'),
                ('library_name', 'City Central Library'),
                ('library_email', 'library@example.com'),
                ('library_phone', '+91-9876543210')
        ''')
        
        # Create admin user if not exists
        cursor.execute('''
            INSERT IGNORE INTO users (username, email, password_hash, full_name, role)
            VALUES ('admin', 'admin@library.com', '$2b$12$YourHashedPasswordHere', 'Administrator', 'admin')
        ''')
        
        mysql.connection.commit()
        cursor.close()