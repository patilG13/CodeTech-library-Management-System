from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
from models.book import Book
from models.transaction import Transaction
from models.user import User
from models.database import mysql

user_bp = Blueprint('user', __name__)

@user_bp.route('/dashboard')
@login_required
def dashboard():
    # Get user's issued books
    cursor = mysql.connection.cursor()
    
    cursor.execute('''
        SELECT t.*, b.title, b.author 
        FROM transactions t
        JOIN books b ON t.book_id = b.id
        WHERE t.user_id = %s AND t.status IN ('issued', 'overdue')
        ORDER BY t.due_date
    ''', (current_user.id,))
    issued_books = cursor.fetchall()
    
    # Calculate total fine
    cursor.execute('''
        SELECT SUM(fine_amount) 
        FROM transactions 
        WHERE user_id = %s AND fine_paid = FALSE AND fine_amount > 0
    ''', (current_user.id,))
    total_fine = cursor.fetchone()[0] or 0
    
    cursor.close()
    
    return render_template('user/dashboard.html',
                         user=current_user,
                         issued_books=issued_books,
                         total_fine=total_fine)

@user_bp.route('/books')
@login_required
def books():
    page = request.args.get('page', 1, type=int)
    per_page = 12
    offset = (page - 1) * per_page
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    
    if search:
        books_list = Book.search(search)
    elif category:
        books_list = Book.search(category, field='category')
    else:
        books_list = Book.get_all(limit=per_page, offset=offset, available_only=True)
    
    categories = Book.get_categories()
    
    return render_template('user/books.html',
                         books=books_list,
                         categories=categories,
                         page=page,
                         search=search,
                         category=category)

@user_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        phone = request.form.get('phone')
        address = request.form.get('address')
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        try:
            # Update basic info
            current_user.update(
                full_name=full_name,
                phone=phone,
                address=address
            )
            
            # Change password if provided
            if current_password and new_password:
                if not current_user.check_password(current_password):
                    flash('Current password is incorrect', 'danger')
                elif new_password != confirm_password:
                    flash('New passwords do not match', 'danger')
                elif len(new_password) < 8:
                    flash('Password must be at least 8 characters', 'danger')
                else:
                    current_user.update(password=new_password)
                    flash('Password updated successfully!', 'success')
            
            flash('Profile updated successfully!', 'success')
        
        except Exception as e:
            flash(f'Error updating profile: {str(e)}', 'danger')
        
        return redirect(url_for('user.profile'))
    
    # Get user's transaction history
    cursor = mysql.connection.cursor()
    cursor.execute('''
        SELECT t.*, b.title, b.author 
        FROM transactions t
        JOIN books b ON t.book_id = b.id
        WHERE t.user_id = %s
        ORDER BY t.created_at DESC
        LIMIT 20
    ''', (current_user.id,))
    history = cursor.fetchall()
    cursor.close()
    
    return render_template('user/profile.html',
                         user=current_user,
                         history=history)

@user_bp.route('/request-book/<int:book_id>', methods=['POST'])
@login_required
def request_book(book_id):
    if not current_user.is_active:
        flash('Your account is deactivated. Please contact administrator.', 'danger')
        return redirect(url_for('user.books'))
    
    book = Book.get_by_id(book_id)
    if not book:
        flash('Book not found', 'danger')
        return redirect(url_for('user.books'))
    
    if book.available_copies <= 0:
        flash('This book is currently unavailable', 'warning')
        return redirect(url_for('user.books'))
    
    # Check if user already has this book issued
    cursor = mysql.connection.cursor()
    cursor.execute('''
        SELECT COUNT(*) FROM transactions 
        WHERE user_id = %s AND book_id = %s AND status IN ('issued', 'overdue')
    ''', (current_user.id, book_id))
    already_issued = cursor.fetchone()[0] > 0
    
    if already_issued:
        flash('You already have this book issued', 'warning')
        cursor.close()
        return redirect(url_for('user.books'))
    
    cursor.close()
    
    # Request book (admin needs to approve in real system)
    # For now, issue directly
    transaction, message = Transaction.issue_book(current_user.id, book_id)
    
    if transaction:
        flash(f'Book "{book.title}" issued successfully!', 'success')
    else:
        flash(message, 'danger')
    
    return redirect(url_for('user.dashboard'))

@user_bp.route('/api/book/<int:book_id>')
@login_required
def api_book_details(book_id):
    book = Book.get_by_id(book_id)
    if not book:
        return jsonify({'error': 'Book not found'}), 404
    
    return jsonify({
        'id': book.id,
        'title': book.title,
        'author': book.author,
        'isbn': book.isbn,
        'publisher': book.publisher,
        'year': book.publication_year,
        'category': book.category,
        'available': book.available_copies,
        'description': book.description
    })