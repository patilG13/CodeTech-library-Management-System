from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
from models.user import User
from models.book import Book
from models.transaction import Transaction
from models.database import mysql
from datetime import datetime, timedelta
import json

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    @login_required
    def decorated_function(*args, **kwargs):
        if current_user.role != 'admin':
            flash('Access denied. Admin privileges required.', 'danger')
            return redirect(url_for('user.dashboard'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    cursor = mysql.connection.cursor()
    
    # Get statistics
    cursor.execute('SELECT COUNT(*) FROM books')
    total_books = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM users WHERE role = "user"')
    total_users = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM transactions WHERE status IN ("issued", "overdue")')
    issued_books = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM transactions WHERE status = "overdue"')
    overdue_books = cursor.fetchone()[0]
    
    cursor.execute('SELECT SUM(fine_amount) FROM transactions WHERE fine_paid = TRUE')
    total_fines = cursor.fetchone()[0] or 0
    
    # Get recent transactions
    cursor.execute('''
        SELECT t.*, u.username, b.title 
        FROM transactions t
        JOIN users u ON t.user_id = u.id
        JOIN books b ON t.book_id = b.id
        ORDER BY t.created_at DESC
        LIMIT 10
    ''')
    recent_transactions = cursor.fetchall()
    
    cursor.close()
    
    return render_template('admin/dashboard.html',
                         total_books=total_books,
                         total_users=total_users,
                         issued_books=issued_books,
                         overdue_books=overdue_books,
                         total_fines=total_fines,
                         recent_transactions=recent_transactions)

@admin_bp.route('/books')
@admin_required
def books():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    offset = (page - 1) * per_page
    
    books_list = Book.get_all(limit=per_page, offset=offset)
    
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT COUNT(*) FROM books')
    total = cursor.fetchone()[0]
    cursor.close()
    
    total_pages = (total + per_page - 1) // per_page
    
    return render_template('admin/books.html',
                         books=books_list,
                         page=page,
                         total_pages=total_pages)

@admin_bp.route('/books/add', methods=['GET', 'POST'])
@admin_required
def add_book():
    if request.method == 'POST':
        isbn = request.form.get('isbn')
        title = request.form.get('title')
        author = request.form.get('author')
        publisher = request.form.get('publisher')
        publication_year = request.form.get('publication_year')
        category = request.form.get('category')
        total_copies = request.form.get('total_copies', 1, type=int)
        price = request.form.get('price')
        description = request.form.get('description')
        
        # Check if ISBN already exists
        existing_book = Book.get_by_isbn(isbn)
        if existing_book:
            flash('A book with this ISBN already exists', 'danger')
            return redirect(url_for('admin.add_book'))
        
        try:
            book = Book.create(
                isbn=isbn,
                title=title,
                author=author,
                publisher=publisher,
                publication_year=publication_year,
                category=category,
                total_copies=total_copies,
                available_copies=total_copies,
                price=price,
                description=description
            )
            
            flash(f'Book "{title}" added successfully!', 'success')
            return redirect(url_for('admin.books'))
        
        except Exception as e:
            flash(f'Error adding book: {str(e)}', 'danger')
    
    return render_template('admin/add_book.html')

@admin_bp.route('/books/edit/<int:book_id>', methods=['GET', 'POST'])
@admin_required
def edit_book(book_id):
    book = Book.get_by_id(book_id)
    if not book:
        flash('Book not found', 'danger')
        return redirect(url_for('admin.books'))
    
    if request.method == 'POST':
        title = request.form.get('title')
        author = request.form.get('author')
        publisher = request.form.get('publisher')
        publication_year = request.form.get('publication_year')
        category = request.form.get('category')
        total_copies = request.form.get('total_copies', type=int)
        available_copies = request.form.get('available_copies', type=int)
        price = request.form.get('price')
        description = request.form.get('description')
        
        # Calculate available copies difference
        copies_diff = total_copies - book.total_copies
        new_available = book.available_copies + copies_diff
        
        if new_available < 0:
            flash('Cannot reduce total copies below currently issued copies', 'danger')
            return redirect(url_for('admin.edit_book', book_id=book_id))
        
        try:
            book.update(
                title=title,
                author=author,
                publisher=publisher,
                publication_year=publication_year,
                category=category,
                total_copies=total_copies,
                available_copies=new_available,
                price=price,
                description=description
            )
            
            flash(f'Book "{title}" updated successfully!', 'success')
            return redirect(url_for('admin.books'))
        
        except Exception as e:
            flash(f'Error updating book: {str(e)}', 'danger')
    
    return render_template('admin/edit_book.html', book=book)

@admin_bp.route('/books/delete/<int:book_id>', methods=['POST'])
@admin_required
def delete_book(book_id):
    book = Book.get_by_id(book_id)
    if not book:
        flash('Book not found', 'danger')
        return redirect(url_for('admin.books'))
    
    # Check if book is currently issued
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT COUNT(*) FROM transactions WHERE book_id = %s AND status IN ("issued", "overdue")', (book_id,))
    issued_count = cursor.fetchone()[0]
    cursor.close()
    
    if issued_count > 0:
        flash('Cannot delete book that is currently issued to users', 'danger')
    else:
        book.delete()
        flash(f'Book "{book.title}" deleted successfully!', 'success')
    
    return redirect(url_for('admin.books'))

@admin_bp.route('/users')
@admin_required
def users():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    offset = (page - 1) * per_page
    
    users_list = User.get_all(limit=per_page, offset=offset)
    user_count = User.count()
    total_pages = (user_count + per_page - 1) // per_page
    
    return render_template('admin/users.html',
                         users=users_list,
                         page=page,
                         total_pages=total_pages)

@admin_bp.route('/users/<int:user_id>/toggle', methods=['POST'])
@admin_required
def toggle_user_status(user_id):
    user = User.get_by_id(user_id)
    if not user:
        flash('User not found', 'danger')
        return redirect(url_for('admin.users'))
    
    new_status = not user.is_active
    user.update(is_active=new_status)
    
    status = 'activated' if new_status else 'deactivated'
    flash(f'User "{user.username}" {status} successfully!', 'success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/issue-book', methods=['GET', 'POST'])
@admin_required
def issue_book():
    if request.method == 'POST':
        user_id = request.form.get('user_id')
        book_id = request.form.get('book_id')
        due_date = request.form.get('due_date')
        
        if not user_id or not book_id:
            flash('Please select both user and book', 'danger')
            return redirect(url_for('admin.issue_book'))
        
        try:
            transaction, message = Transaction.issue_book(user_id, book_id)
            if transaction:
                flash(message, 'success')
            else:
                flash(message, 'danger')
        except Exception as e:
            flash(f'Error issuing book: {str(e)}', 'danger')
        
        return redirect(url_for('admin.issue_book'))
    
    # Get all active users
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT id, username, full_name FROM users WHERE is_active = TRUE AND role = "user"')
    users = cursor.fetchall()
    
    # Get available books
    cursor.execute('SELECT id, title, author, available_copies FROM books WHERE available_copies > 0')
    books = cursor.fetchall()
    
    cursor.close()
    
    return render_template('admin/issue_book.html', users=users, books=books)

@admin_bp.route('/returns')
@admin_required
def returns():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    offset = (page - 1) * per_page
    
    transactions = Transaction.get_all_transactions(limit=per_page, offset=offset)
    
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT COUNT(*) FROM transactions')
    total = cursor.fetchone()[0]
    cursor.close()
    
    total_pages = (total + per_page - 1) // per_page
    
    return render_template('admin/returns.html',
                         transactions=transactions,
                         page=page,
                         total_pages=total_pages)

@admin_bp.route('/return-book/<int:transaction_id>', methods=['POST'])
@admin_required
def return_book(transaction_id):
    transaction, message = Transaction.return_book(transaction_id)
    flash(message, 'success' if transaction else 'danger')
    return redirect(url_for('admin.returns'))

@admin_bp.route('/reports')
@admin_required
def reports():
    report_type = request.args.get('type', 'daily')
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    cursor = mysql.connection.cursor()
    
    # Default to current month if no dates provided
    if not start_date or not end_date:
        today = datetime.now()
        start_date = today.replace(day=1).strftime('%Y-%m-%d')
        end_date = today.strftime('%Y-%m-%d')
    
    if report_type == 'issued':
        cursor.execute('''
            SELECT DATE(t.issue_date) as date, COUNT(*) as count, 
                   GROUP_CONCAT(b.title SEPARATOR ', ') as books
            FROM transactions t
            JOIN books b ON t.book_id = b.id
            WHERE t.issue_date BETWEEN %s AND %s
            GROUP BY DATE(t.issue_date)
            ORDER BY date DESC
        ''', (start_date, end_date))
        data = cursor.fetchall()
    
    elif report_type == 'returns':
        cursor.execute('''
            SELECT DATE(t.return_date) as date, COUNT(*) as count,
                   SUM(t.fine_amount) as total_fine
            FROM transactions t
            WHERE t.return_date BETWEEN %s AND %s
            GROUP BY DATE(t.return_date)
            ORDER BY date DESC
        ''', (start_date, end_date))
        data = cursor.fetchall()
    
    elif report_type == 'overdue':
        cursor.execute('''
            SELECT u.username, u.full_name, b.title, t.due_date,
                   DATEDIFF(CURDATE(), t.due_date) as days_overdue,
                   t.fine_amount
            FROM transactions t
            JOIN users u ON t.user_id = u.id
            JOIN books b ON t.book_id = b.id
            WHERE t.status = 'overdue'
            ORDER BY t.due_date
        ''')
        data = cursor.fetchall()
    
    elif report_type == 'fines':
        cursor.execute('''
            SELECT u.username, u.full_name, 
                   SUM(t.fine_amount) as total_fine,
                   SUM(CASE WHEN t.fine_paid THEN t.fine_amount ELSE 0 END) as paid,
                   SUM(CASE WHEN NOT t.fine_paid THEN t.fine_amount ELSE 0 END) as unpaid
            FROM transactions t
            JOIN users u ON t.user_id = u.id
            WHERE t.fine_amount > 0
            GROUP BY u.id
            ORDER BY total_fine DESC
        ''')
        data = cursor.fetchall()
    
    else:  # Daily summary
        cursor.execute('''
            SELECT 
                DATE(t.created_at) as date,
                COUNT(*) as total_transactions,
                SUM(CASE WHEN t.status = 'issued' THEN 1 ELSE 0 END) as issued,
                SUM(CASE WHEN t.status = 'returned' THEN 1 ELSE 0 END) as returned,
                SUM(CASE WHEN t.status = 'overdue' THEN 1 ELSE 0 END) as overdue,
                SUM(t.fine_amount) as total_fine
            FROM transactions t
            WHERE t.created_at BETWEEN %s AND %s
            GROUP BY DATE(t.created_at)
            ORDER BY date DESC
        ''', (start_date, end_date))
        data = cursor.fetchall()
    
    cursor.close()
    
    return render_template('admin/reports.html',
                         report_type=report_type,
                         start_date=start_date,
                         end_date=end_date,
                         data=data)

@admin_bp.route('/api/statistics')
@admin_required
def api_statistics():
    cursor = mysql.connection.cursor()
    
    # Monthly statistics for chart
    cursor.execute('''
        SELECT 
            DATE_FORMAT(created_at, '%Y-%m') as month,
            COUNT(*) as transactions
        FROM transactions
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ORDER BY month
    ''')
    monthly_stats = cursor.fetchall()
    
    # Category distribution
    cursor.execute('''
        SELECT category, COUNT(*) as count
        FROM books
        WHERE category IS NOT NULL
        GROUP BY category
        ORDER BY count DESC
        LIMIT 10
    ''')
    category_stats = cursor.fetchall()
    
    cursor.close()
    
    return jsonify({
        'monthly_stats': [{'month': m[0], 'transactions': m[1]} for m in monthly_stats],
        'category_stats': [{'category': c[0] or 'Uncategorized', 'count': c[1]} for c in category_stats]
    })