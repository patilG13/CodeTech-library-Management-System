from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from flask_login import login_user, logout_user, login_required, current_user
from models.user import User
from utils.validators import validate_email, validate_password
import logging

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin.dashboard'))
        else:
            return redirect(url_for('user.dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Try to find user by username or email
        user = User.get_by_username(username)
        if not user:
            user = User.get_by_email(username)
        
        if user and user.check_password(password):
            if user.is_active:
                login_user(user)
                session['user_role'] = user.role
                
                # Set session as permanent
                session.permanent = True
                
                flash('Login successful!', 'success')
                
                if user.role == 'admin':
                    return redirect(url_for('admin.dashboard'))
                else:
                    return redirect(url_for('user.dashboard'))
            else:
                flash('Your account is deactivated. Please contact administrator.', 'danger')
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('auth/login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('user.dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        full_name = request.form.get('full_name')
        phone = request.form.get('phone')
        address = request.form.get('address')
        
        # Validation
        errors = []
        
        if not username or len(username) < 3:
            errors.append('Username must be at least 3 characters long')
        
        if not validate_email(email):
            errors.append('Invalid email address')
        
        if not validate_password(password):
            errors.append('Password must be at least 8 characters with uppercase, lowercase, and numbers')
        
        if password != confirm_password:
            errors.append('Passwords do not match')
        
        if User.get_by_username(username):
            errors.append('Username already exists')
        
        if User.get_by_email(email):
            errors.append('Email already registered')
        
        if errors:
            for error in errors:
                flash(error, 'danger')
        else:
            try:
                user = User.create(
                    username=username,
                    email=email,
                    password=password,
                    full_name=full_name,
                    phone=phone,
                    address=address,
                    role='user'
                )
                
                flash('Registration successful! Please login.', 'success')
                return redirect(url_for('auth.login'))
            
            except Exception as e:
                logging.error(f"Registration error: {str(e)}")
                flash('Registration failed. Please try again.', 'danger')
    
    return render_template('auth/register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('auth.login'))