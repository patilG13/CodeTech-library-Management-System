from flask import Flask, render_template, redirect, url_for, flash, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import os
from sqlalchemy import or_

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or 'dev-key-123'

# Use SQLite for now (no MySQL setup needed)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///library.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(20), default='user')  # 'admin' or 'user'
    phone = db.Column(db.String(15))
    address = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    isbn = db.Column(db.String(20), unique=True, nullable=False)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    publisher = db.Column(db.String(100))
    publication_year = db.Column(db.Integer)
    category = db.Column(db.String(50))
    total_copies = db.Column(db.Integer, default=1)
    available_copies = db.Column(db.Integer, default=1)
    price = db.Column(db.Float)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class BookRequest(db.Model):  # MOVED THIS HERE - BEFORE Transaction model
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    request_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='pending')  # 'pending', 'approved', 'rejected'
    admin_notes = db.Column(db.Text)
    processed_date = db.Column(db.DateTime)
    
    user = db.relationship('User', backref=db.backref('book_requests', lazy=True))
    book = db.relationship('Book', backref=db.backref('requests', lazy=True))

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    issue_date = db.Column(db.Date, nullable=False)
    due_date = db.Column(db.Date, nullable=False)
    return_date = db.Column(db.Date)
    status = db.Column(db.String(20), default='issued')  # 'issued', 'returned', 'overdue'
    fine_amount = db.Column(db.Float, default=0)
    fine_paid = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref=db.backref('transactions', lazy=True))
    book = db.relationship('Book', backref=db.backref('transactions', lazy=True))

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ==================== Routes ====================

@app.route('/')
def home():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('user_dashboard'))
    return render_template('home.html')

# ==================== Authentication Routes ====================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('user_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        if not user:
            user = User.query.filter_by(email=username).first()
        
        if user and user.check_password(password):
            if user.is_active:
                login_user(user, remember=True)
                flash('Login successful!', 'success')
                
                if user.role == 'admin':
                    return redirect(url_for('admin_dashboard'))
                else:
                    return redirect(url_for('user_dashboard'))
            else:
                flash('Account is deactivated', 'danger')
        else:
            flash('Invalid credentials', 'danger')
    
    return render_template('auth/login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('user_dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        full_name = request.form.get('full_name')
        
        # Simple validation
        if len(password) < 6:
            flash('Password must be at least 6 characters', 'danger')
            return redirect(url_for('register'))
        
        # Check if user exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
        elif User.query.filter_by(email=email).first():
            flash('Email already registered', 'danger')
        else:
            user = User(
                username=username,
                email=email,
                full_name=full_name,
                role='user'
            )
            user.set_password(password)
            
            db.session.add(user)
            db.session.commit()
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
    
    return render_template('auth/register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully', 'info')
    return redirect(url_for('login'))

# ==================== Admin Routes ====================

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    # Calculate statistics
    total_books = Book.query.count() or 0
    total_users = User.query.filter_by(role='user').count() or 0
    issued_books = Transaction.query.filter(Transaction.status.in_(['issued', 'overdue'])).count() or 0
    overdue_books = Transaction.query.filter_by(status='overdue').count() or 0
    
    # Calculate fine collection
    fine_collected_result = db.session.query(db.func.sum(Transaction.fine_amount)).filter(
        Transaction.fine_paid == True
    ).scalar()
    fine_collected = fine_collected_result or 0
    
    # Recent transactions
    recent_transactions = Transaction.query.order_by(
        Transaction.created_at.desc()
    ).limit(10).all()
    
    # Recent users
    recent_users = User.query.filter_by(role='user').order_by(
        User.created_at.desc()
    ).limit(5).all()
    
    stats = {
        'total_books': total_books,
        'total_users': total_users,
        'issued_books': issued_books,
        'overdue_books': overdue_books,
        'fine_collected': fine_collected
    }
    
    return render_template('admin/dashboard.html',
                         stats=stats,
                         recent_transactions=recent_transactions,
                         recent_users=recent_users)
# ==================== Book Management ====================

@app.route('/admin/books')
@login_required
def admin_books():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    page = request.args.get('page', 1, type=int)
    per_page = 10
    search = request.args.get('search', '')
    
    if search:
        books = Book.query.filter(
            or_(
                Book.title.ilike(f'%{search}%'),
                Book.author.ilike(f'%{search}%'),
                Book.isbn.ilike(f'%{search}%'),
                Book.category.ilike(f'%{search}%')
            )
        ).order_by(Book.title).paginate(page=page, per_page=per_page, error_out=False)
    else:
        books = Book.query.order_by(Book.title).paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('admin/books.html', books=books, search=search)

@app.route('/admin/books/add', methods=['GET', 'POST'])
@login_required
def add_book():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    if request.method == 'POST':
        try:
            book = Book(
                isbn=request.form.get('isbn'),
                title=request.form.get('title'),
                author=request.form.get('author'),
                publisher=request.form.get('publisher'),
                publication_year=request.form.get('publication_year', type=int),
                category=request.form.get('category'),
                total_copies=request.form.get('total_copies', 1, type=int),
                available_copies=request.form.get('total_copies', 1, type=int),
                price=request.form.get('price', type=float),
                description=request.form.get('description')
            )
            db.session.add(book)
            db.session.commit()
            flash('Book added successfully!', 'success')
            return redirect(url_for('admin_books'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding book: {str(e)}', 'danger')
    
    return render_template('admin/add_book.html')

@app.route('/admin/books/edit/<int:book_id>', methods=['GET', 'POST'])
@login_required
def edit_book(book_id):
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    book = Book.query.get_or_404(book_id)
    
    if request.method == 'POST':
        try:
            # Calculate available copies difference
            new_total = request.form.get('total_copies', type=int)
            diff = new_total - book.total_copies
            
            book.isbn = request.form.get('isbn')
            book.title = request.form.get('title')
            book.author = request.form.get('author')
            book.publisher = request.form.get('publisher')
            book.publication_year = request.form.get('publication_year', type=int)
            book.category = request.form.get('category')
            book.total_copies = new_total
            book.available_copies = max(0, book.available_copies + diff)
            book.price = request.form.get('price', type=float)
            book.description = request.form.get('description')
            
            db.session.commit()
            flash('Book updated successfully!', 'success')
            return redirect(url_for('admin_books'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating book: {str(e)}', 'danger')
    
    return render_template('admin/edit_book.html', book=book)

@app.route('/admin/books/delete/<int:book_id>', methods=['POST'])
@login_required
def delete_book(book_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    book = Book.query.get_or_404(book_id)
    
    try:
        # Check if book is issued
        issued_count = Transaction.query.filter_by(
            book_id=book_id, 
            status='issued'
        ).count()
        
        if issued_count > 0:
            return jsonify({'success': False, 'message': 'Cannot delete book that is currently issued'})
        
        db.session.delete(book)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Book deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

# ==================== User Management ====================

@app.route('/admin/users')
@login_required
def admin_users():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    page = request.args.get('page', 1, type=int)
    per_page = 10
    search = request.args.get('search', '')
    
    if search:
        users = User.query.filter(
            or_(
                User.username.ilike(f'%{search}%'),
                User.full_name.ilike(f'%{search}%'),
                User.email.ilike(f'%{search}%')
            ),
            User.role == 'user'
        ).order_by(User.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    else:
        users = User.query.filter_by(role='user').order_by(
            User.created_at.desc()
        ).paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('admin/users.html', users=users, search=search)

@app.route('/admin/users/toggle/<int:user_id>', methods=['POST'])
@login_required
def toggle_user_status(user_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    user = User.query.get_or_404(user_id)
    
    try:
        user.is_active = not user.is_active
        db.session.commit()
        status = 'activated' if user.is_active else 'deactivated'
        return jsonify({
            'success': True, 
            'message': f'User {status} successfully',
            'is_active': user.is_active
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

# ==================== Issue Book ====================

@app.route('/admin/issue-book', methods=['GET', 'POST'])
@login_required
def issue_book():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    if request.method == 'POST':
        try:
            user_id = request.form.get('user_id', type=int)
            book_id = request.form.get('book_id', type=int)
            due_days = request.form.get('due_days', 14, type=int)
            
            user = User.query.get_or_404(user_id)
            book = Book.query.get_or_404(book_id)
            
            # Check if book is available
            if book.available_copies <= 0:
                flash('Book is not available', 'danger')
                return redirect(url_for('issue_book'))
            
            # Check if user already has this book issued
            existing = Transaction.query.filter_by(
                user_id=user_id, 
                book_id=book_id, 
                status='issued'
            ).first()
            
            if existing:
                flash('User already has this book issued', 'danger')
                return redirect(url_for('issue_book'))
            
            # Create transaction
            transaction = Transaction(
                user_id=user_id,
                book_id=book_id,
                issue_date=datetime.now().date(),
                due_date=datetime.now().date() + timedelta(days=due_days),
                status='issued'
            )
            
            # Update book availability
            book.available_copies -= 1
            
            db.session.add(transaction)
            db.session.commit()
            
            flash(f'Book "{book.title}" issued to {user.full_name} successfully!', 'success')
            return redirect(url_for('issue_book'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error issuing book: {str(e)}', 'danger')
    
    # Get data for the form
    users = User.query.filter_by(role='user', is_active=True).all()
    books = Book.query.filter(Book.available_copies > 0).all()
    
    return render_template('admin/issue_book.html', users=users, books=books)

# ==================== Return Book ====================

@app.route('/admin/return-book', methods=['GET', 'POST'])
@login_required
def return_book():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    if request.method == 'POST':
        transaction_id = request.form.get('transaction_id', type=int)
        
        try:
            transaction = Transaction.query.get_or_404(transaction_id)
            
            if transaction.status == 'returned':
                flash('Book already returned', 'warning')
                return redirect(url_for('return_book'))
            
            # Calculate fine if overdue
            return_date = datetime.now().date()
            fine_amount = 0
            
            if return_date > transaction.due_date:
                days_overdue = (return_date - transaction.due_date).days
                fine_amount = days_overdue * 10  # ₹10 per day
            
            # Update transaction
            transaction.return_date = return_date
            transaction.status = 'returned'
            transaction.fine_amount = fine_amount
            
            # Update book availability
            book = Book.query.get(transaction.book_id)
            book.available_copies += 1
            
            db.session.commit()
            
            if fine_amount > 0:
                flash(f'Book returned with fine: ₹{fine_amount}', 'warning')
            else:
                flash('Book returned successfully!', 'success')
                
        except Exception as e:
            db.session.rollback()
            flash(f'Error returning book: {str(e)}', 'danger')
    
    # Get issued books
    issued_books = Transaction.query.filter_by(status='issued').all()
    overdue_books = Transaction.query.filter_by(status='overdue').all()
    
    return render_template('admin/return_book.html', 
                         issued_books=issued_books,
                         overdue_books=overdue_books)

@app.route('/admin/transactions')
@login_required
def admin_transactions():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    page = request.args.get('page', 1, type=int)
    per_page = 15
    status = request.args.get('status', '')
    
    query = Transaction.query
    
    if status:
        query = query.filter_by(status=status)
    
    transactions = query.order_by(
        Transaction.created_at.desc()
    ).paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('admin/transactions.html', 
                         transactions=transactions, 
                         status=status)

# ==================== Reports ====================

@app.route('/admin/reports')
@login_required
def admin_reports():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    # Get date range from query parameters
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date') or datetime.now().date().isoformat()
    
    if not start_date:
        # Default to last 30 days
        start_date = (datetime.now() - timedelta(days=30)).date().isoformat()
    
    # Convert string dates to datetime
    start_dt = datetime.fromisoformat(start_date)
    end_dt = datetime.fromisoformat(end_date)
    
    # Generate different reports
    issue_report = Transaction.query.filter(
        Transaction.issue_date.between(start_dt, end_dt)
    ).all()
    
    return_report = Transaction.query.filter(
        Transaction.return_date.between(start_dt, end_dt)
    ).all()
    
    overdue_report = Transaction.query.filter_by(status='overdue').all()
    
    # Fine collection report
    fine_report = Transaction.query.filter(
        Transaction.fine_amount > 0,
        Transaction.return_date.between(start_dt, end_dt)
    ).all()
    
    total_fine = sum(t.fine_amount for t in fine_report if t.fine_paid)
    
    return render_template('admin/reports.html',
                         start_date=start_date,
                         end_date=end_date,
                         issue_report=issue_report,
                         return_report=return_report,
                         overdue_report=overdue_report,
                         fine_report=fine_report,
                         total_fine=total_fine)

# ==================== Settings ====================

@app.route('/admin/settings', methods=['GET', 'POST'])
@login_required
def admin_settings():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    if request.method == 'POST':
        # Handle settings update
        if 'change_password' in request.form:
            old_password = request.form.get('old_password')
            new_password = request.form.get('new_password')
            confirm_password = request.form.get('confirm_password')
            
            if not current_user.check_password(old_password):
                flash('Current password is incorrect', 'danger')
            elif new_password != confirm_password:
                flash('New passwords do not match', 'danger')
            elif len(new_password) < 6:
                flash('Password must be at least 6 characters', 'danger')
            else:
                current_user.set_password(new_password)
                db.session.commit()
                flash('Password changed successfully!', 'success')
    
    return render_template('admin/settings.html')

# ==================== User Routes ====================

@app.route('/user/dashboard')
@login_required
def user_dashboard():
    # Get user's issued books
    issued_books = Transaction.query.filter_by(
        user_id=current_user.id, 
        status='issued'
    ).all()
    
    # Get overdue books
    overdue_books = Transaction.query.filter_by(
        user_id=current_user.id, 
        status='overdue'
    ).all()
    
    # Calculate total fine
    fine_result = db.session.query(db.func.sum(Transaction.fine_amount)).filter(
        Transaction.user_id == current_user.id,
        Transaction.fine_paid == False
    ).scalar()
    total_fine = fine_result or 0
    
    # Get reading history
    history = Transaction.query.filter_by(
        user_id=current_user.id
    ).order_by(Transaction.created_at.desc()).limit(10).all()
    
    return render_template('user/dashboard.html',
                         issued_books=issued_books,
                         overdue_books=overdue_books,
                         total_fine=total_fine,
                         history=history)

@app.route('/user/books')
@login_required
def user_books():
    page = request.args.get('page', 1, type=int)
    per_page = 12
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    
    query = Book.query.filter(Book.available_copies > 0)
    
    if search:
        query = query.filter(
            or_(
                Book.title.ilike(f'%{search}%'),
                Book.author.ilike(f'%{search}%'),
                Book.isbn.ilike(f'%{search}%')
            )
        )
    
    if category:
        query = query.filter_by(category=category)
    
    books = query.order_by(Book.title).paginate(page=page, per_page=per_page, error_out=False)
    
    # Get all categories for filter
    categories = db.session.query(Book.category).distinct().all()
    categories = [c[0] for c in categories if c[0]]
    
    return render_template('user/books.html', 
                         books=books, 
                         categories=categories,
                         search=search,
                         category=category)

@app.route('/user/profile', methods=['GET', 'POST'])
@login_required
def user_profile():
    if request.method == 'POST':
        try:
            current_user.full_name = request.form.get('full_name')
            current_user.phone = request.form.get('phone')
            current_user.address = request.form.get('address')
            
            # Change password if provided
            old_password = request.form.get('old_password')
            new_password = request.form.get('new_password')
            
            if old_password and new_password:
                if current_user.check_password(old_password):
                    current_user.set_password(new_password)
                    flash('Password changed successfully!', 'success')
                else:
                    flash('Current password is incorrect', 'danger')
            
            db.session.commit()
            flash('Profile updated successfully!', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating profile: {str(e)}', 'danger')
    
    return render_template('user/profile.html')

@app.route('/user/history')
@login_required
def user_history():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    history = Transaction.query.filter_by(
        user_id=current_user.id
    ).order_by(Transaction.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return render_template('user/history.html', history=history)

# ==================== Book Request Routes ====================

# REMOVE THE DUPLICATE ROUTE - Keep only this one
@app.route('/user/books/request/<int:book_id>', methods=['POST'])
@login_required
def request_book(book_id):
    book = Book.query.get_or_404(book_id)
    
    # Check if book is available
    if book.available_copies <= 0:
        flash('Book is not available for request', 'danger')
        return redirect(url_for('user_books'))
    
    # Check if user already requested this book
    existing_request = BookRequest.query.filter_by(
        user_id=current_user.id,
        book_id=book_id,
        status='pending'
    ).first()
    
    if existing_request:
        flash('You already have a pending request for this book', 'warning')
        return redirect(url_for('user_books'))
    
    # Create new request
    book_request = BookRequest(
        user_id=current_user.id,
        book_id=book_id
    )
    
    try:
        db.session.add(book_request)
        db.session.commit()
        flash(f'Request for "{book.title}" submitted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error submitting request: {str(e)}', 'danger')
    
    return redirect(url_for('user_books'))

@app.route('/user/requests')
@login_required
def user_requests():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    requests = BookRequest.query.filter_by(
        user_id=current_user.id
    ).order_by(BookRequest.request_date.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return render_template('user/requests.html', requests=requests)

@app.route('/user/requests/cancel/<int:request_id>', methods=['POST'])
@login_required
def cancel_request(request_id):
    book_request = BookRequest.query.get_or_404(request_id)
    
    # Check if user owns this request
    if book_request.user_id != current_user.id:
        flash('Access denied', 'danger')
        return redirect(url_for('user_requests'))
    
    # Check if request is still pending
    if book_request.status != 'pending':
        flash('Cannot cancel a request that has already been processed', 'warning')
        return redirect(url_for('user_requests'))
    
    try:
        db.session.delete(book_request)
        db.session.commit()
        flash('Request cancelled successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error cancelling request: {str(e)}', 'danger')
    
    return redirect(url_for('user_requests'))

@app.route('/admin/requests')
@login_required
def admin_requests():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    page = request.args.get('page', 1, type=int)
    per_page = 10
    status = request.args.get('status', 'pending')
    
    query = BookRequest.query
    
    if status:
        query = query.filter_by(status=status)
    
    requests = query.order_by(
        BookRequest.request_date.desc()
    ).paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('admin/requests.html', 
                         requests=requests, 
                         status=status)

@app.route('/admin/requests/process/<int:request_id>', methods=['POST'])
@login_required
def process_request(request_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    book_request = BookRequest.query.get_or_404(request_id)
    action = request.form.get('action')
    notes = request.form.get('notes', '')
    
    try:
        if action == 'approve':
            # Check if book is still available
            book = Book.query.get(book_request.book_id)
            
            if book.available_copies <= 0:
                return jsonify({
                    'success': False, 
                    'message': 'Book is no longer available'
                })
            
            # Create transaction
            transaction = Transaction(
                user_id=book_request.user_id,
                book_id=book_request.book_id,
                issue_date=datetime.now().date(),
                due_date=datetime.now().date() + timedelta(days=14),
                status='issued'
            )
            
            # Update book availability
            book.available_copies -= 1
            
            # Update request status
            book_request.status = 'approved'
            book_request.admin_notes = notes
            book_request.processed_date = datetime.utcnow()
            
            db.session.add(transaction)
            flash('Request approved and book issued successfully!', 'success')
            
        elif action == 'reject':
            book_request.status = 'rejected'
            book_request.admin_notes = notes
            book_request.processed_date = datetime.utcnow()
            flash('Request rejected successfully!', 'info')
        
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': f'Request {action}d successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500
    
@app.route('/admin/users/add', methods=['GET', 'POST'])
@login_required
def admin_add_user():
    if current_user.role != 'admin':
        flash('Access denied', 'danger')
        return redirect(url_for('user_dashboard'))
    
    if request.method == 'POST':
        try:
            username = request.form.get('username')
            email = request.form.get('email')
            password = request.form.get('password')
            full_name = request.form.get('full_name')
            phone = request.form.get('phone')
            address = request.form.get('address')
            
            # Validation
            if len(password) < 6:
                return jsonify({'success': False, 'message': 'Password must be at least 6 characters'})
            
            if User.query.filter_by(username=username).first():
                return jsonify({'success': False, 'message': 'Username already exists'})
            
            if User.query.filter_by(email=email).first():
                return jsonify({'success': False, 'message': 'Email already registered'})
            
            # Create user
            user = User(
                username=username,
                email=email,
                full_name=full_name,
                phone=phone,
                address=address,
                role='user'
            )
            user.set_password(password)
            
            db.session.add(user)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'User added successfully!'})
            
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)})
    
    # For GET request, render the form
    return render_template('admin/add_user.html')
    
# ==================== Search Functionality ====================

@app.route('/search')
def search():
    query = request.args.get('q', '')
    
    if not query:
        return redirect(url_for('home'))
    
    # Search books
    books = Book.query.filter(
        or_(
            Book.title.ilike(f'%{query}%'),
            Book.author.ilike(f'%{query}%'),
            Book.isbn.ilike(f'%{query}%'),
            Book.category.ilike(f'%{query}%')
        )
    ).limit(20).all()
    
    # Search users (admin only)
    users = []
    if current_user.is_authenticated and current_user.role == 'admin':
        users = User.query.filter(
            or_(
                User.username.ilike(f'%{query}%'),
                User.full_name.ilike(f'%{query}%'),
                User.email.ilike(f'%{query}%')
            )
        ).limit(10).all()
    
    return render_template('search.html', 
                         query=query, 
                         books=books, 
                         users=users)

@app.context_processor
def utility_processor():
    def now(format=None):
        from datetime import datetime
        current = datetime.now()
        if format:
            return current.strftime(format)
        return current
    
    return dict(now=now)

# ==================== Initialize Database ====================

with app.app_context():
    try:
        db.create_all()
        
        # Create admin user if not exists
        if not User.query.filter_by(username='admin').first():
            admin = User(
                username='admin',
                email='admin@library.com',
                full_name='Administrator',
                role='admin'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print("✓ Admin user created: admin/admin123")
        
        # Create demo user if not exists
        if not User.query.filter_by(username='demo').first():
            demo = User(
                username='demo',
                email='demo@library.com',
                full_name='Demo User',
                role='user'
            )
            demo.set_password('demo123')
            db.session.add(demo)
            db.session.commit()
            print("✓ Demo user created: demo/demo123")
        
        # Add sample books if no books exist
        if Book.query.count() == 0:
            sample_books = [
                Book(
                    isbn='9780140283334',
                    title='To Kill a Mockingbird',
                    author='Harper Lee',
                    publisher='Penguin Books',
                    publication_year=1960,
                    category='Fiction',
                    total_copies=5,
                    available_copies=5,
                    price=3.99,
                    description='A classic novel about racial injustice in the American South.'
                ),
                Book(
                    isbn='9780743273565',
                    title='The Great Gatsby',
                    author='F. Scott Fitzgerald',
                    publisher='Scribner',
                    publication_year=1925,
                    category='Fiction',
                    total_copies=3,
                    available_copies=3,
                    price=2.99,
                    description='A story of the mysteriously wealthy Jay Gatsby and his love for Daisy Buchanan.'
                ),
                Book(
                    isbn='9780547928227',
                    title='The Hobbit',
                    author='J.R.R. Tolkien',
                    publisher='Houghton Mifflin',
                    publication_year=1937,
                    category='Fantasy',
                    total_copies=4,
                    available_copies=4,
                    price=4.99,
                    description='Bilbo Baggins goes on an unexpected adventure with a group of dwarves.'
                ),
                Book(
                    isbn='9780439023481',
                    title='The Hunger Games',
                    author='Suzanne Collins',
                    publisher='Scholastic',
                    publication_year=2008,
                    category='Science Fiction',
                    total_copies=6,
                    available_copies=6,
                    price=5.99,
                    description='In a dystopian future, teenagers fight to the death in a televised event.'
                ),
                Book(
                    isbn='9781408855652',
                    title='Harry Potter and the Philosopher\'s Stone',
                    author='J.K. Rowling',
                    publisher='Bloomsbury',
                    publication_year=1997,
                    category='Fantasy',
                    total_copies=8,
                    available_copies=8,
                    price=6.99,
                    description='Harry Potter discovers he is a wizard and attends Hogwarts School.'
                ),
                Book(
                    isbn='9780061120084',
                    title='1984',
                    author='George Orwell',
                    publisher='Secker & Warburg',
                    publication_year=1949,
                    category='Dystopian',
                    total_copies=4,
                    available_copies=4,
                    price=3.49,
                    description='A dystopian social science fiction novel and cautionary tale.'
                ),
                Book(
                    isbn='9781451673319',
                    title='Fahrenheit 451',
                    author='Ray Bradbury',
                    publisher='Simon & Schuster',
                    publication_year=1953,
                    category='Dystopian',
                    total_copies=3,
                    available_copies=3,
                    price=3.29,
                    description='A dystopian novel about a future American society where books are outlawed.'
                ),
                Book(
                    isbn='9780141187761',
                    title='Animal Farm',
                    author='George Orwell',
                    publisher='Penguin Books',
                    publication_year=1945,
                    category='Political Satire',
                    total_copies=5,
                    available_copies=5,
                    price=2.99,
                    description='An allegorical novella about animals who rebel against their human farmer.'
                ),
                Book(
                    isbn='9780141439518',
                    title='Pride and Prejudice',
                    author='Jane Austen',
                    publisher='Penguin Classics',
                    publication_year=1813,
                    category='Romance',
                    total_copies=4,
                    available_copies=4,
                    price=3.49,
                    description='A romantic novel of manners that depicts the emotional development of protagonist Elizabeth Bennet.'
                ),
                Book(
                    isbn='9780316769174',
                    title='The Catcher in the Rye',
                    author='J.D. Salinger',
                    publisher='Little, Brown',
                    publication_year=1951,
                    category='Fiction',
                    total_copies=3,
                    available_copies=3,
                    price=3.79,
                    description='A story about Holden Caulfield\'s experiences in New York City.'
                )
            ]
            
            for book in sample_books:
                db.session.add(book)
            db.session.commit()
            print("✓ Added 10 sample books")
        
        print("✓ Database initialized successfully!")
        
    except Exception as e:
        print(f"✗ Database initialization error: {e}")

# ==================== Run Application ====================

if __name__ == '__main__':
    print("=" * 60)
    print("Library Management System")
    print("=" * 60)
    print("Starting server on http://localhost:5000")
    print("\nDefault login:")
    print("  Admin: admin / admin123")
    print("  User: demo / demo123")
    print("=" * 60)
    app.run(debug=True, port=5000)