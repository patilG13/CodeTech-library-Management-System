import os
import sys
import subprocess

def run_command(command):
    """Run a shell command"""
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✓ {command}")
            return True
        else:
            print(f"✗ {command}")
            print(f"  Error: {result.stderr}")
            return False
    except Exception as e:
        print(f"✗ {command}")
        print(f"  Exception: {str(e)}")
        return False

def main():
    print("=" * 60)
    print("Library Management System - Windows Setup")
    print("=" * 60)
    
    # Step 1: Create virtual environment
    print("\n1. Setting up virtual environment...")
    if not os.path.exists("venv"):
        run_command("python -m venv venv")
    else:
        print("✓ Virtual environment already exists")
    
    # Step 2: Activate virtual environment (informational)
    print("\n2. To activate virtual environment:")
    print("   venv\\Scripts\\activate")
    
    # Step 3: Install requirements
    print("\n3. Installing requirements...")
    run_command("venv\\Scripts\\pip install --upgrade pip")
    run_command("venv\\Scripts\\pip install flask flask-login flask-wtf wtforms pymysql python-dotenv bcrypt PyJWT flask-sqlalchemy")
    
    # Step 4: Check MySQL
    print("\n4. Checking MySQL...")
    print("   Please ensure MySQL is installed and running")
    print("   You can download MySQL from: https://dev.mysql.com/downloads/installer/")
    
    # Step 5: Create .env file
    print("\n5. Creating environment file...")
    env_content = """# Flask Configuration
SECRET_KEY=your-secret-key-change-this-in-production
FLASK_ENV=development

# Database Configuration
MYSQL_HOST=localhost
MYSQL_USER=root
MYSQL_PASSWORD=
MYSQL_DB=library_db
MYSQL_PORT=3306

# Application Settings
DEBUG=True
"""
    
    with open(".env", "w") as f:
        f.write(env_content)
    print("✓ Created .env file")
    
    # Step 6: Instructions
    print("\n" + "=" * 60)
    print("SETUP COMPLETED!")
    print("=" * 60)
    
    print("\nNext steps:")
    print("1. Start MySQL server (if not running)")
    print("2. Create database: CREATE DATABASE library_db;")
    print("3. Activate virtual environment:")
    print("   venv\\Scripts\\activate")
    print("4. Run the application:")
    print("   python app.py")
    print("5. Open browser: http://localhost:5000")
    print("\nDefault admin login:")
    print("   Username: admin")
    print("   Password: admin123")

if __name__ == "__main__":
    main()