<?php
session_start();
if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || 
    $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['error'] = "Security token invalid. Please try again.";
    header("Location: ../index.php");
    exit();
}
if(!isset($_POST['book_id']) && !isset($_GET['id'])) {
    $_SESSION['error'] = "No book specified.";
    header("Location: ../index.php");
    exit();
}

$id = isset($_POST['book_id']) ? $_POST['book_id'] : $_GET['id'];

require_once '../config/database.php';
require_once '../models/Book.php';

$database = new Database();
$db = $database->getConnection();

$book = new Book($db);
$book->id = $id;

try {
    if($book->returnBook()) {
        $_SESSION['success'] = "Book returned successfully!";
        $_SESSION['toast_success'] = "✓ Book returned successfully!";
    } else {
        $_SESSION['error'] = "Unable to return book. All copies are already available.";
        $_SESSION['toast_error'] = "✗ Unable to return book.";
    }
} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
    $_SESSION['toast_error'] = "✗ " . $e->getMessage();
}
if (isset($_POST['referrer']) && filter_var($_POST['referrer'], FILTER_VALIDATE_URL)) {
    header("Location: " . $_POST['referrer']);
} else {
    header("Location: ../views/books/show.php?id=" . $id);
}
exit();
?>