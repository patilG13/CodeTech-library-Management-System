<?php
session_start();
require_once '../config/database.php';
require_once '../models/Book.php';

if(isset($_GET['id'])) {
    $database = new Database();
    $db = $database->getConnection();
    
    $book = new Book($db);
    $book->id = $_GET['id'];
    if($book->delete()) {
        $_SESSION['message'] = "Book deleted successfully!";
    } else {
        $_SESSION['error'] = "Unable to delete book. Please try again.";
    }
}
header("Location: ../index.php");
exit();
?>