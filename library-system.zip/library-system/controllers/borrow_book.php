<?php
session_start();

if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || 
    $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['error'] = "Security token invalid. Please try again.";
    header("Location: ../index.php");
    exit();
}
if(!isset($_POST['book_id']) && !isset($_GET['id'])) {
    $_SESSION['error'] = "No book specified.";
    header("Location: ../index.php");
    exit();
}

$id = isset($_POST['book_id']) ? $_POST['book_id'] : $_GET['id'];

require_once '../config/database.php';
require_once '../models/Book.php';

$database = new Database();
$db = $database->getConnection();

$book = new Book($db);
$book->id = $id;

try {
    if($book->borrow()) {
        $_SESSION['success'] = "Book borrowed successfully!";
        
        $_SESSION['toast_success'] = "✓ Book borrowed successfully!";
    } else {
        $_SESSION['error'] = "Unable to borrow book. No copies available.";
        $_SESSION['toast_error'] = "✗ Unable to borrow book. No copies available.";
    }
} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
    $_SESSION['toast_error'] = "✗ " . $e->getMessage();
}

if (isset($_POST['referrer']) && filter_var($_POST['referrer'], FILTER_VALIDATE_URL)) {
    header("Location: " . $_POST['referrer']);
} else {
    header("Location: ../views/books/show.php?id=" . $id);
}
exit();
?>