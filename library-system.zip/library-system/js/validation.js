
(function() {
    'use strict';
    const forms = document.querySelectorAll('.needs-validation');

    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
})();

// Real-time input validation
document.addEventListener('DOMContentLoaded', function() {
    // Title validation
    const titleInput = document.getElementById('title');
    if (titleInput) {
        titleInput.addEventListener('input', function() {
            if (this.value.length < 3) {
                this.classList.add('is-invalid');
                this.classList.remove('is-valid');
            } else {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            }
        });
    }
    
    // ISBN format validation
    function validateISBN(isbn) {
        isbn = isbn.replace(/[-\s]/g, '');
        
        if (isbn.length === 10) {
            return validateISBN10(isbn);
        } else if (isbn.length === 13) {
            return validateISBN13(isbn);
        }
        return false;
    }
    
    function validateISBN10(isbn) {
        let sum = 0;
        for (let i = 0; i < 9; i++) {
            sum += (10 - i) * parseInt(isbn.charAt(i));
        }
        let checkDigit = isbn.charAt(9).toUpperCase();
        sum += (checkDigit === 'X') ? 10 : parseInt(checkDigit);
        return sum % 11 === 0;
    }
    
    function validateISBN13(isbn) {
        let sum = 0;
        for (let i = 0; i < 12; i++) {
            sum += (i % 2 === 0) ? parseInt(isbn.charAt(i)) : parseInt(isbn.charAt(i)) * 3;
        }
        let checkDigit = (10 - (sum % 10)) % 10;
        return checkDigit === parseInt(isbn.charAt(12));
    }
    
    // Quantity validation
    const quantityInput = document.getElementById('quantity');
    if (quantityInput) {
        quantityInput.addEventListener('change', function() {
            if (this.value < 1 || this.value > 1000) {
                this.classList.add('is-invalid');
                this.classList.remove('is-valid');
            } else {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            }
        });
    }
    
    // Show toast messages from session
    if (typeof toastr !== 'undefined') {
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "timeOut": "5000"
        };
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menuToggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('show');
        });
        
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.navbar')) {
                navLinks.classList.remove('show');
            }
        });
    }
});