<?php
session_start();
require_once '../../config/database.php';
require_once '../../models/Book.php';

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle form submission
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Security token invalid. Please try again.";
    } else {
        $database = new Database();
        $db = $database->getConnection();
        
        $book = new Book($db);
        
        // Sanitize and validate inputs
        $book->title = trim($_POST['title']);
        $book->author = trim($_POST['author']);
        $book->isbn = trim($_POST['isbn']);
        $book->genre = $_POST['genre'];
        $book->publication_year = (int)$_POST['publication_year'];
        $book->quantity = (int)$_POST['quantity'];
        $book->available = (int)$_POST['quantity']; // Initially all copies available
        
        try {
            // Check if ISBN already exists
            if ($book->isbnExists()) {
                $error = "A book with this ISBN already exists.";
            } elseif($book->create()) {
                $_SESSION['success'] = "Book created successfully!";
                header("Location: ../../index.php");
                exit();
            } else {
                $error = "Unable to create book. Please try again.";
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Book - Library Management System</title>
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</head>
<body>
    <?php include '../layout/header.php'; ?>
    
    <div class="container">
        <div class="dashboard-header">
            <h1><i class="fas fa-plus-circle"></i> Add New Book</h1>
            <a href="../../index.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <div class="form-container">
            <?php if(isset($error)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
                    <button class="close-alert" onclick="this.parentElement.style.display='none'">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" 
                  id="createBookForm" class="needs-validation" novalidate>
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                
                <div class="form-group">
                    <label for="title"><i class="fas fa-book"></i> Book Title *</label>
                    <input type="text" class="form-control" id="title" name="title" 
                           placeholder="Enter book title" required maxlength="255"
                           pattern=".{3,255}" 
                           title="Title must be between 3 and 255 characters">
                    <div class="invalid-feedback">Please enter a valid book title (3-255 characters).</div>
                </div>
                
                <div class="form-group">
                    <label for="author"><i class="fas fa-user"></i> Author *</label>
                    <input type="text" class="form-control" id="author" name="author" 
                           placeholder="Enter author name" required maxlength="255"
                           pattern=".{2,255}"
                           title="Author name must be between 2 and 255 characters">
                    <div class="invalid-feedback">Please enter a valid author name.</div>
                </div>
                
                <div class="form-group">
                    <label for="isbn"><i class="fas fa-barcode"></i> ISBN *</label>
                    <input type="text" class="form-control" id="isbn" name="isbn" 
                           placeholder="Enter ISBN-10 or ISBN-13" required
                           pattern="(?:\d{9}[\dX]|\d{13})"
                           title="Enter valid ISBN-10 or ISBN-13 format">
                    <small class="form-text text-muted">Format: ISBN-10 (10 digits) or ISBN-13 (13 digits)</small>
                    <div class="invalid-feedback">Please enter a valid ISBN number.</div>
                </div>
                
                <div class="form-group">
                    <label for="genre"><i class="fas fa-tags"></i> Genre</label>
                    <select class="form-control" id="genre" name="genre">
                        <option value="">Select a genre</option>
                        <option value="Fiction">Fiction</option>
                        <option value="Non-Fiction">Non-Fiction</option>
                        <option value="Science">Science</option>
                        <option value="Technology">Technology</option>
                        <option value="History">History</option>
                        <option value="Biography">Biography</option>
                        <option value="Romance">Romance</option>
                        <option value="Mystery">Mystery</option>
                        <option value="Fantasy">Fantasy</option>
                        <option value="Dystopian">Dystopian</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="publication_year"><i class="fas fa-calendar-alt"></i> Publication Year</label>
                        <input type="number" class="form-control" id="publication_year" name="publication_year" 
                               min="1000" max="<?php echo date('Y'); ?>"
                               value="<?php echo date('Y'); ?>">
                        <div class="invalid-feedback">Year must be between 1000 and <?php echo date('Y'); ?></div>
                    </div>
                    
                    <div class="form-group">
                        <label for="quantity"><i class="fas fa-copy"></i> Quantity *</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" 
                               min="1" max="1000" value="1" required>
                        <div class="invalid-feedback">Quantity must be between 1 and 1000.</div>
                    </div>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary" id="submitBtn">
                        <i class="fas fa-save"></i> Save Book
                        <span class="spinner-border spinner-border-sm d-none" role="status"></span>
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Reset
                    </button>
                    <a href="../../index.php" class="btn btn-outline">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <?php include '../layout/footer.php'; ?>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="../../js/validation.js"></script>
    <script>
    // Real-time ISBN validation
    document.getElementById('isbn').addEventListener('blur', function() {
        const isbn = this.value.replace(/[-\s]/g, '');
        if (isbn.length === 10 || isbn.length === 13) {
            this.classList.remove('is-invalid');
            this.classList.add('is-valid');
        } else {
            this.classList.remove('is-valid');
            this.classList.add('is-invalid');
        }
    });

    // Form submission handling
    document.getElementById('createBookForm').addEventListener('submit', function(e) {
        const submitBtn = document.getElementById('submitBtn');
        submitBtn.disabled = true;
        submitBtn.querySelector('.spinner-border').classList.remove('d-none');
    });

    // Auto-focus first field
    document.getElementById('title').focus();
    </script>
</body>
</html>