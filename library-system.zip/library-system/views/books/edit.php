<?php
// views/books/edit.php
session_start();
require_once '../../config/database.php';
require_once '../../models/Book.php';

// Check if ID is provided
if(!isset($_GET['id'])) {
    header("Location: ../../index.php");
    exit();
}

$id = $_GET['id'];

// Database connection
$database = new Database();
$db = $database->getConnection();

$book = new Book($db);
$book->id = $id;

// Get book details
if(!$book->readOne()) {
    header("Location: ../../index.php");
    exit();
}

// Handle form submission
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Update book properties
    $book->title = $_POST['title'];
    $book->author = $_POST['author'];
    $book->isbn = $_POST['isbn'];
    $book->genre = $_POST['genre'];
    $book->publication_year = $_POST['publication_year'];
    $book->quantity = $_POST['quantity'];
    $book->available = $_POST['available'];
    
    // Update book
    if($book->update()) {
        $_SESSION['message'] = "Book updated successfully!";
        header("Location: show.php?id=" . $id);
        exit();
    } else {
        $error = "Unable to update book. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book - Library Management System</title>
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../layout/header.php'; ?>
    
    <div class="container">
        <div class="dashboard-header">
            <h1><i class="fas fa-edit"></i> Edit Book</h1>
            <a href="show.php?id=<?php echo $id; ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Book Details
            </a>
        </div>
        
        <div class="form-container">
            <?php if(isset($error)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="title"><i class="fas fa-book"></i> Book Title *</label>
                    <input type="text" class="form-control" id="title" name="title" 
                           value="<?php echo htmlspecialchars($book->title); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="author"><i class="fas fa-user"></i> Author *</label>
                    <input type="text" class="form-control" id="author" name="author" 
                           value="<?php echo htmlspecialchars($book->author); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="isbn"><i class="fas fa-barcode"></i> ISBN *</label>
                    <input type="text" class="form-control" id="isbn" name="isbn" 
                           value="<?php echo htmlspecialchars($book->isbn); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="genre"><i class="fas fa-tags"></i> Genre</label>
                    <select class="form-control" id="genre" name="genre">
                        <option value="Fiction" <?php echo $book->genre == 'Fiction' ? 'selected' : ''; ?>>Fiction</option>
                        <option value="Non-Fiction" <?php echo $book->genre == 'Non-Fiction' ? 'selected' : ''; ?>>Non-Fiction</option>
                        <option value="Science" <?php echo $book->genre == 'Science' ? 'selected' : ''; ?>>Science</option>
                        <option value="Technology" <?php echo $book->genre == 'Technology' ? 'selected' : ''; ?>>Technology</option>
                        <option value="History" <?php echo $book->genre == 'History' ? 'selected' : ''; ?>>History</option>
                        <option value="Biography" <?php echo $book->genre == 'Biography' ? 'selected' : ''; ?>>Biography</option>
                        <option value="Romance" <?php echo $book->genre == 'Romance' ? 'selected' : ''; ?>>Romance</option>
                        <option value="Mystery" <?php echo $book->genre == 'Mystery' ? 'selected' : ''; ?>>Mystery</option>
                        <option value="Fantasy" <?php echo $book->genre == 'Fantasy' ? 'selected' : ''; ?>>Fantasy</option>
                        <option value="Dystopian" <?php echo $book->genre == 'Dystopian' ? 'selected' : ''; ?>>Dystopian</option>
                        <option value="Other" <?php echo $book->genre == 'Other' ? 'selected' : ''; ?>>Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="publication_year"><i class="fas fa-calendar-alt"></i> Publication Year</label>
                    <input type="number" class="form-control" id="publication_year" name="publication_year" 
                           min="1000" max="<?php echo date('Y'); ?>" 
                           value="<?php echo $book->publication_year; ?>">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="quantity"><i class="fas fa-copy"></i> Total Quantity *</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" 
                               min="1" value="<?php echo $book->quantity; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="available"><i class="fas fa-check-circle"></i> Available Copies *</label>
                        <input type="number" class="form-control" id="available" name="available" 
                               min="0" max="<?php echo $book->quantity; ?>" 
                               value="<?php echo $book->available; ?>" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Book
                    </button>
                    <a href="show.php?id=<?php echo $id; ?>" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <?php include '../layout/footer.php'; ?>
    
    <style>
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</body>
</html>