<?php
// views/books/index.php
session_start();
require_once '../../config/database.php';
require_once '../../models/Book.php';

// Database connection
$database = new Database();
$db = $database->getConnection();

$book = new Book($db);

// Check for search
if(isset($_GET['search']) && !empty($_GET['search'])) {
    $keywords = $_GET['search'];
    $stmt = $book->search($keywords);
} else {
    $stmt = $book->read();
}

$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Books - Library Management System</title>
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../layout/header.php'; ?>
    
    <div class="container">
        <div class="dashboard-header">
            <h1><i class="fas fa-list"></i> All Books</h1>
            <div>
                <a href="../../index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <a href="create.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add New Book
                </a>
            </div>
        </div>

        <!-- Search Form -->
        <div class="search-container">
            <form method="GET" action="" class="search-form">
                <div class="search-box">
                    <input type="text" name="search" placeholder="Search books by title, author, or genre..." 
                           value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    <button type="submit" class="btn-search">
                        <i class="fas fa-search"></i> Search
                    </button>
                    <?php if(isset($_GET['search'])): ?>
                        <a href="index.php" class="btn-clear">Clear</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Books Table -->
        <div class="table-container">
            <div class="table-header">
                <h2><?php echo isset($_GET['search']) ? 'Search Results' : 'All Books'; ?></h2>
                <span class="book-count"><?php echo count($books); ?> books found</span>
            </div>
            
            <?php if(count($books) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>ISBN</th>
                        <th>Genre</th>
                        <th>Year</th>
                        <th>Quantity</th>
                        <th>Available</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($books as $book_item): ?>
                    <tr>
                        <td>#<?php echo $book_item['id']; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($book_item['title']); ?></strong>
                        </td>
                        <td><?php echo htmlspecialchars($book_item['author']); ?></td>
                        <td><code><?php echo $book_item['isbn']; ?></code></td>
                        <td>
                            <span class="genre-badge"><?php echo htmlspecialchars($book_item['genre']); ?></span>
                        </td>
                        <td><?php echo $book_item['publication_year']; ?></td>
                        <td><?php echo $book_item['quantity']; ?></td>
                        <td>
                            <?php if($book_item['available'] > 0): ?>
                                <span class="status available">
                                    <?php echo $book_item['available']; ?> available
                                </span>
                            <?php else: ?>
                                <span class="status unavailable">
                                    Out of stock
                                </span>
                            <?php endif; ?>
                        </td>
                        <td class="actions">
                            <a href="show.php?id=<?php echo $book_item['id']; ?>" 
                               class="btn-action view" title="View">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="edit.php?id=<?php echo $book_item['id']; ?>" 
                               class="btn-action edit" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="../../controllers/delete_book.php?id=<?php echo $book_item['id']; ?>" 
                               class="btn-action delete" 
                               onclick="return confirm('Are you sure you want to delete this book?')" 
                               title="Delete">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="no-data">
                <i class="fas fa-search"></i>
                <p>No books found.</p>
                <?php if(isset($_GET['search'])): ?>
                    <p>No results for "<?php echo htmlspecialchars($_GET['search']); ?>"</p>
                    <a href="index.php" class="btn btn-secondary" style="margin-top: 15px;">
                        <i class="fas fa-list"></i> View All Books
                    </a>
                <?php else: ?>
                    <p>The library is empty. Add your first book!</p>
                    <a href="create.php" class="btn btn-primary" style="margin-top: 15px;">
                        <i class="fas fa-plus"></i> Add First Book
                    </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php include '../layout/footer.php'; ?>
</body>
</html>