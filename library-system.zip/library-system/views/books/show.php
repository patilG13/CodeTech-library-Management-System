<?php
// views/books/show.php
session_start();
require_once '../../config/database.php';
require_once '../../models/Book.php';

// Check if ID is provided
if(!isset($_GET['id'])) {
    header("Location: ../../index.php");
    exit();
}

$id = $_GET['id'];

// Database connection
$database = new Database();
$db = $database->getConnection();

$book = new Book($db);
$book->id = $id;

// Get book details
if(!$book->readOne()) {
    header("Location: ../../index.php");
    exit();
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Format ISBN for display
function formatISBN($isbn) {
    $clean_isbn = preg_replace('/[^0-9X]/', '', $isbn);
    
    if (empty($clean_isbn)) {
        return $isbn;
    }
    
    $length = strlen($clean_isbn);
    
    if ($length == 10) {
        return substr($clean_isbn, 0, 1) . '-' . 
               substr($clean_isbn, 1, 3) . '-' . 
               substr($clean_isbn, 4, 5) . '-' . 
               substr($clean_isbn, 9, 1);
    }
    
    if ($length == 13) {
        return substr($clean_isbn, 0, 3) . '-' . 
               substr($clean_isbn, 3, 1) . '-' . 
               substr($clean_isbn, 4, 4) . '-' . 
               substr($clean_isbn, 8, 4) . '-' . 
               substr($clean_isbn, 12, 1);
    }
    
    return $isbn;
}

// Current URL for referrer
$current_url = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($book->title); ?> - Library Management System</title>
    <link rel="stylesheet" href="../../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <style>
        /* Add these styles to your existing CSS */
        .borrow-form {
            display: inline;
        }
        
        .borrow-btn {
            background: #2ecc71;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .borrow-btn:hover {
            background: #27ae60;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(46, 204, 113, 0.3);
        }
        
        .return-btn {
            background: #f39c12;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .return-btn:hover {
            background: #e67e22;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(243, 156, 18, 0.3);
        }
        
        .btn-loading {
            position: relative;
            color: transparent !important;
        }
        
        .btn-loading:after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            top: 50%;
            left: 50%;
            margin-left: -10px;
            margin-top: -10px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top: 2px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: space-between;
            animation: slideIn 0.3s ease;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .alert .close-btn {
            background: none;
            border: none;
            color: inherit;
            cursor: pointer;
            font-size: 18px;
        }
        
        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <?php include '../layout/header.php'; ?>
    
    <div class="container">
        <div class="dashboard-header">
            <h1><i class="fas fa-book-open"></i> Book Details</h1>
            <div>
                <a href="../../index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Edit Book
                </a>
            </div>
        </div>

        <!-- Success/Error Messages -->
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <div>
                    <i class="fas fa-check-circle"></i> 
                    <?php echo htmlspecialchars($_SESSION['success']); ?>
                </div>
                <button class="close-btn" onclick="this.parentElement.remove()">&times;</button>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <div>
                    <i class="fas fa-exclamation-circle"></i> 
                    <?php echo htmlspecialchars($_SESSION['error']); ?>
                </div>
                <button class="close-btn" onclick="this.parentElement.remove()">&times;</button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <div class="book-details-container">
            <div class="book-details-card">
                <div class="book-cover">
                    <i class="fas fa-book fa-5x"></i>
                </div>
                <div class="book-info">
                    <h2><?php echo htmlspecialchars($book->title); ?></h2>
                    <p class="book-author">
                        <i class="fas fa-user"></i> 
                        <?php echo htmlspecialchars($book->author); ?>
                    </p>
                    
                    <div class="details-grid">
                        <div class="detail-item">
                            <strong><i class="fas fa-barcode"></i> ISBN:</strong>
                            <span><?php echo formatISBN($book->isbn); ?></span>
                        </div>
                        <div class="detail-item">
                            <strong><i class="fas fa-tags"></i> Genre:</strong>
                            <span class="genre-badge"><?php echo htmlspecialchars($book->genre); ?></span>
                        </div>
                        <div class="detail-item">
                            <strong><i class="fas fa-calendar-alt"></i> Publication Year:</strong>
                            <span><?php echo $book->publication_year; ?></span>
                        </div>
                        <div class="detail-item">
                            <strong><i class="fas fa-copy"></i> Total Copies:</strong>
                            <span><?php echo $book->quantity; ?></span>
                        </div>
                        <div class="detail-item">
                            <strong><i class="fas fa-check-circle"></i> Available Copies:</strong>
                            <span class="status <?php echo $book->available > 0 ? 'available' : 'unavailable'; ?>">
                                <?php echo $book->available; ?>
                            </span>
                        </div>
                        <div class="detail-item">
                            <strong><i class="fas fa-times-circle"></i> Borrowed Copies:</strong>
                            <span><?php echo $book->quantity - $book->available; ?></span>
                        </div>
                    </div>
                    
                    <div class="action-buttons">
                        <!-- Borrow Form -->
                        <?php if($book->available > 0): ?>
                            <form method="POST" action="../../controllers/borrow_book.php" class="borrow-form" 
                                  onsubmit="return confirmBorrow()" id="borrowForm">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <input type="hidden" name="book_id" value="<?php echo $id; ?>">
                                <input type="hidden" name="referrer" value="<?php echo $current_url; ?>">
                                <button type="submit" class="btn borrow-btn" id="borrowBtn">
                                    <i class="fas fa-book-reader"></i> Borrow This Book
                                </button>
                            </form>
                        <?php else: ?>
                            <button class="btn btn-secondary" disabled>
                                <i class="fas fa-ban"></i> Not Available for Borrowing
                            </button>
                        <?php endif; ?>
                        
                        <!-- Return Form (show only if there are borrowed copies) -->
                        <?php if($book->quantity - $book->available > 0): ?>
                            <form method="POST" action="../../controllers/return_book.php" class="borrow-form" 
                                  onsubmit="return confirmReturn()">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <input type="hidden" name="book_id" value="<?php echo $id; ?>">
                                <input type="hidden" name="referrer" value="<?php echo $current_url; ?>">
                                <button type="submit" class="btn return-btn">
                                    <i class="fas fa-undo"></i> Return a Copy
                                </button>
                            </form>
                        <?php endif; ?>
                        
                        <div style="display: flex; gap: 10px; margin-top: 10px;">
                            <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-primary">
                                <i class="fas fa-edit"></i> Edit Book
                            </a>
                            <a href="../../controllers/delete_book.php?id=<?php echo $id; ?>" 
                               class="btn btn-danger" 
                               onclick="return confirmDelete()">
                                <i class="fas fa-trash"></i> Delete Book
                            </a>
                        </div>
                    </div>
                    
                    <!-- Quick Stats -->
                    <div class="quick-stats" style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                        <h3><i class="fas fa-chart-bar"></i> Quick Stats</h3>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-top: 15px;">
                            <div style="text-align: center;">
                                <div style="font-size: 24px; font-weight: bold; color: #3498db;"><?php echo $book->quantity; ?></div>
                                <div style="font-size: 14px; color: #7f8c8d;">Total Copies</div>
                            </div>
                            <div style="text-align: center;">
                                <div style="font-size: 24px; font-weight: bold; color: #2ecc71;"><?php echo $book->available; ?></div>
                                <div style="font-size: 14px; color: #7f8c8d;">Available Now</div>
                            </div>
                            <div style="text-align: center;">
                                <div style="font-size: 24px; font-weight: bold; color: #e74c3c;"><?php echo $book->quantity - $book->available; ?></div>
                                <div style="font-size: 14px; color: #7f8c8d;">Currently Borrowed</div>
                            </div>
                            <div style="text-align: center;">
                                <div style="font-size: 24px; font-weight: bold; color: #f39c12;">
                                    <?php echo $book->quantity > 0 ? round(($book->available / $book->quantity) * 100) : 0; ?>%
                                </div>
                                <div style="font-size: 14px; color: #7f8c8d;">Availability Rate</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php include '../layout/footer.php'; ?>
    
    <!-- Add Toastr JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    
    <script>
        // Toastr configuration
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "timeOut": "5000",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };
        
        // Show toast messages from PHP session
        <?php if(isset($_SESSION['toast_success'])): ?>
            toastr.success('<?php echo $_SESSION['toast_success']; ?>');
            <?php unset($_SESSION['toast_success']); ?>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['toast_error'])): ?>
            toastr.error('<?php echo $_SESSION['toast_error']; ?>');
            <?php unset($_SESSION['toast_error']); ?>
        <?php endif; ?>
        
        // Confirmation functions
        function confirmBorrow() {
            const bookTitle = "<?php echo addslashes($book->title); ?>";
            const available = <?php echo $book->available; ?>;
            
            if (available <= 0) {
                toastr.error('No copies available for borrowing!');
                return false;
            }
            
            const confirmMsg = `Borrow "${bookTitle}"?\n\nThis will reduce available copies from ${available} to ${available - 1}.`;
            
            if (!confirm(confirmMsg)) {
                return false;
            }
            
            // Show loading state
            const borrowBtn = document.getElementById('borrowBtn');
            borrowBtn.classList.add('btn-loading');
            borrowBtn.disabled = true;
            
            return true;
        }
        
        function confirmReturn() {
            const bookTitle = "<?php echo addslashes($book->title); ?>";
            const available = <?php echo $book->available; ?>;
            const total = <?php echo $book->quantity; ?>;
            
            if (available >= total) {
                toastr.error('All copies are already available!');
                return false;
            }
            
            const confirmMsg = `Return a copy of "${bookTitle}"?\n\nThis will increase available copies from ${available} to ${available + 1}.`;
            
            return confirm(confirmMsg);
        }
        
        function confirmDelete() {
            const bookTitle = "<?php echo addslashes($book->title); ?>";
            return confirm(`Are you sure you want to delete "${bookTitle}"?\n\nThis action cannot be undone and all data will be permanently lost.`);
        }
        
        // Auto-close alerts after 5 seconds
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.style.transition = 'opacity 0.5s';
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 500);
            });
        }, 5000);
        
        // Close alert on button click
        document.querySelectorAll('.alert .close-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                this.parentElement.style.transition = 'opacity 0.3s';
                this.parentElement.style.opacity = '0';
                setTimeout(() => this.parentElement.remove(), 300);
            });
        });
        
        // Real-time availability update (optional - can refresh page)
        function updateAvailability() {
            // In a real application, you might use AJAX here
            // For simplicity, we'll just show a message
            console.log('Availability would update here...');
        }
    </script>
    
    <!-- Keep your existing CSS styles here -->
    <style>
        .book-details-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .book-details-card {
            display: flex;
            gap: 30px;
            align-items: flex-start;
        }
        
        .book-cover {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            width: 200px;
            height: 250px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .book-info {
            flex: 1;
        }
        
        .book-info h2 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .book-author {
            color: #7f8c8d;
            margin-bottom: 20px;
            font-size: 18px;
        }
        
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin: 25px 0;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .detail-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        
        .detail-item:last-child {
            border-bottom: none;
        }
        
        .detail-item strong {
            color: #2c3e50;
        }
        
        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        
        .btn-primary {
            background: #3498db;
            color: white;
            padding: 12px 25px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary:hover {
            background: #2980b9;
        }
        
        .btn-danger {
            background: #e74c3c;
            color: white;
            padding: 12px 25px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-danger:hover {
            background: #c0392b;
        }
        
        @media (max-width: 768px) {
            .book-details-card {
                flex-direction: column;
            }
            
            .book-cover {
                width: 100%;
                max-width: 200px;
                margin: 0 auto;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .borrow-form, .return-form {
                width: 100%;
            }
            
            .borrow-btn, .return-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</body>
</html>