<?php
?>
    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Library Management System. All rights reserved.</p>
        </div>
    </footer>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const successMessages = document.querySelectorAll('.alert-success');
            successMessages.forEach(message => {
                setTimeout(() => {
                    message.style.transition = 'opacity 0.5s';
                    message.style.opacity = '0';
                    setTimeout(() => message.remove(), 500);
                }, 5000);
            });
            
            // Form validation
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    const requiredFields = this.querySelectorAll('[required]');
                    let isValid = true;
                    
                    requiredFields.forEach(field => {
                        if (!field.value.trim()) {
                            isValid = false;
                            field.style.borderColor = '#e74c3c';
                            
                            // Create error message
                            if (!field.nextElementSibling || !field.nextElementSibling.classList.contains('error-message')) {
                                const error = document.createElement('div');
                                error.className = 'error-message';
                                error.style.color = '#e74c3c';
                                error.style.fontSize = '12px';
                                error.style.marginTop = '5px';
                                error.textContent = 'This field is required';
                                field.parentNode.appendChild(error);
                            }
                        } else {
                            field.style.borderColor = '#ddd';
                            const errorMsg = field.nextElementSibling;
                            if (errorMsg && errorMsg.classList.contains('error-message')) {
                                errorMsg.remove();
                            }
                        }
                    });
                    
                    if (!isValid) {
                        e.preventDefault();
                        alert('Please fill all required fields.');
                    }
                });
            });
            
            // Search functionality enhancement
            const searchInput = document.querySelector('input[name="search"]');
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase();
                    if (searchTerm.length >= 2) {
                        // You could add AJAX live search here
                        console.log('Searching for:', searchTerm);
                    }
                });
            }
        });
    </script>
</body>
</html>