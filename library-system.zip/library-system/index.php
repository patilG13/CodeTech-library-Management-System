<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';
require_once 'models/Book.php';

// Initialize variables
$books = [];
$error = null;
$setup_needed = false;

try {
    // Create database connection
    $database = new Database();
    $db = $database->getConnection();
    
    if ($db) {
        // Check if we can query the database
        $stmt = $db->query("SELECT 1");
        if ($stmt) {
            // Create Book instance
            $book = new Book($db);
            
            // Try to get books
            $stmt = $book->read();
            
            if ($stmt) {
                $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } else {
                $error = "Unable to fetch books from database.";
            }
        } else {
            $error = "Database connection test failed.";
            $setup_needed = true;
        }
    } else {
        $error = "Could not create database connection.";
        $setup_needed = true;
    }
} catch (Exception $e) {
    $error = "Error: " . $e->getMessage();
    $setup_needed = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .connection-test {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            border-left: 4px solid #3498db;
        }
        
        .connection-test.success {
            border-left-color: #2ecc71;
            background: #e8f5e9;
        }
        
        .connection-test.error {
            border-left-color: #e74c3c;
            background: #ffebee;
        }
    </style>
</head>
<body>
    <?php include 'views/layout/header.php'; ?>
    
    <div class="container">
        <!-- Connection Test Result -->
        <?php if(isset($error) && !$setup_needed): ?>
        <div class="connection-test error">
            <h3><i class="fas fa-exclamation-triangle"></i> Database Error</h3>
            <p><?php echo htmlspecialchars($error); ?></p>
            <p>But connection to MySQL was successful. The issue might be:</p>
            <ol>
                <li>Books table doesn't exist</li>
                <li>Table structure is different than expected</li>
                <li>Permissions issue</li>
            </ol>
            <a href="?reset=1" class="btn btn-warning" onclick="return confirm('This will reset the database. Continue?')">
                <i class="fas fa-redo"></i> Reset Database
            </a>
        </div>
        <?php endif; ?>
        
        <?php if($setup_needed): ?>
        <!-- Setup instructions (keep your existing setup guide) -->
        <?php include 'views/setup/setup_guide.php'; ?>
        <?php else: ?>
        
        <!-- Main Dashboard -->
        <div class="dashboard-header">
            <h1><i class="fas fa-book"></i> Library Management System</h1>
            <div class="header-actions">
                <a href="views/books/create.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add New Book
                </a>
                <a href="views/books/index.php" class="btn btn-secondary">
                    <i class="fas fa-list"></i> View All Books
                </a>
            </div>
        </div>
        
        <!-- Search -->
        <div class="search-container">
            <form action="views/books/index.php" method="GET" class="search-form">
                <div class="search-box">
                    <input type="text" name="search" placeholder="Search books..." 
                           value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    <button type="submit" class="btn btn-search">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Statistics -->
        <?php
        $total_books = count($books);
        $total_copies = 0;
        $available_copies = 0;
        
        foreach($books as $book_item) {
            $total_copies += $book_item['quantity'];
            $available_copies += $book_item['available'];
        }
        ?>
        
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon" style="background: #4CAF50;">
                    <i class="fas fa-book"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $total_books; ?></h3>
                    <p>Total Books</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background: #2196F3;">
                    <i class="fas fa-copy"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $total_copies; ?></h3>
                    <p>Total Copies</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background: #FF9800;">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $available_copies; ?></h3>
                    <p>Available Copies</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon" style="background: #F44336;">
                    <i class="fas fa-times-circle"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $total_copies - $available_copies; ?></h3>
                    <p>Borrowed Copies</p>
                </div>
            </div>
        </div>
        
        <!-- Books Table -->
        <div class="table-container">
            <div class="table-header">
                <h2><i class="fas fa-book-open"></i> Recent Books</h2>
                <?php if($total_books > 0): ?>
                <a href="views/books/index.php" class="btn btn-secondary">
                    View All <i class="fas fa-arrow-right"></i>
                </a>
                <?php endif; ?>
            </div>
            
            <?php if($total_books > 0): ?>
            <div class="table-responsive">
                <table class="table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Genre</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $recent_books = array_slice($books, 0, 5);
                        foreach($recent_books as $book): 
                        ?>
                        <tr>
                            <td>#<?php echo $book['id']; ?></td>
                            <td><?php echo htmlspecialchars($book['title']); ?></td>
                            <td><?php echo htmlspecialchars($book['author']); ?></td>
                            <td><span class="genre-badge"><?php echo htmlspecialchars($book['genre']); ?></span></td>
                            <td>
                                <?php if($book['available'] > 0): ?>
                                    <span class="status available">
                                        <i class="fas fa-check-circle"></i> Available
                                    </span>
                                <?php else: ?>
                                    <span class="status unavailable">
                                        <i class="fas fa-times-circle"></i> Out of Stock
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="actions">
                                <a href="views/books/show.php?id=<?php echo $book['id']; ?>" 
                                   class="btn-action view" title="View">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="views/books/edit.php?id=<?php echo $book['id']; ?>" 
                                   class="btn-action edit" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if($total_books > 5): ?>
            <div class="view-all">
                <a href="views/books/index.php" class="btn btn-secondary">
                    <i class="fas fa-list"></i> View All <?php echo $total_books; ?> Books
                </a>
            </div>
            <?php endif; ?>
            
            <?php else: ?>
            <div class="no-data">
                <div class="no-data-icon">
                    <i class="fas fa-book-open fa-3x"></i>
                </div>
                <h3>No Books in Library</h3>
                <p>Start by adding your first book to the library system.</p>
                <a href="views/books/create.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add First Book
                </a>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <?php include 'views/layout/footer.php'; ?>
</body>
</html>