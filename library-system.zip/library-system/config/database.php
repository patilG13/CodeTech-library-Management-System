<?php
class Database {
    private $host = "localhost";
    private $db_name = "library_db";
    private $username = "root";
    private $password = "";
    public $conn;
    
    public function getConnection() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host=" . $this->host . ";charset=utf8mb4";
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("CREATE DATABASE IF NOT EXISTS `$this->db_name` 
                             CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4";
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->createTable();
            
            return $this->conn;
            
        } catch(PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }
    
    private function createTable() {
        $sql = "CREATE TABLE IF NOT EXISTS books (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            author VARCHAR(255) NOT NULL,
            isbn VARCHAR(20) UNIQUE NOT NULL,
            genre VARCHAR(100),
            publication_year INT,
            quantity INT DEFAULT 1,
            available INT DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $this->conn->exec($sql);
        $stmt = $this->conn->query("SELECT COUNT(*) as count FROM books");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result['count'] == 0) {
            $this->insertSampleData();
        }
    }
    
    private function insertSampleData() {
        $sql = "INSERT INTO books (title, author, isbn, genre, publication_year, quantity, available) VALUES 
                ('The Great Gatsby', 'F. Scott Fitzgerald', '9780743273565', 'Fiction', 1925, 3, 2),
                ('To Kill a Mockingbird', 'Harper Lee', '9780061120084', 'Fiction', 1960, 5, 3),
                ('1984', 'George Orwell', '9780451524935', 'Dystopian', 1949, 4, 4),
                ('Pride and Prejudice', 'Jane Austen', '9780141439518', 'Romance', 1813, 2, 1),
                ('The Hobbit', 'J.R.R. Tolkien', '9780547928227', 'Fantasy', 1937, 3, 2)";
        
        $this->conn->exec($sql);
    }
}
?>