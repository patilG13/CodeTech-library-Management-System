<?php
// setup.php - Database auto-setup script
session_start();

require_once 'config/database.php';

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if($db) {
        $_SESSION['success'] = "✅ Database setup completed successfully!";
        header("Location: index.php");
        exit();
    } else {
        $_SESSION['error'] = "❌ Database setup failed. Please check your MySQL server.";
        header("Location: index.php");
        exit();
    }
} catch(Exception $e) {
    $_SESSION['error'] = "Setup Error: " . $e->getMessage();
    header("Location: index.php");
    exit();
}
?>