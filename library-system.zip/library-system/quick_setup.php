<?php
// quick_setup.php - Create all missing files at once
$files = [
    'views/layout/header.php' => '<?php
// views/layout/header.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="logo">
                <i class="fas fa-book"></i>
                <span>Library System</span>
            </div>
            <div class="nav-links">
                <a href="../../index.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
                <a href="../books/index.php" class="nav-link"><i class="fas fa-list"></i> All Books</a>
                <a href="../books/create.php" class="nav-link"><i class="fas fa-plus"></i> Add Book</a>
            </div>
        </nav>
    </header>',
    
    'views/layout/footer.php' => '<?php
// views/layout/footer.php
?>
    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date(\'Y\'); ?> Library Management System. All rights reserved.</p>
            <p>Developed for Internship Project | PHP, MySQL, HTML, CSS</p>
        </div>
    </footer>
</body>
</html>'
];

echo "<h2>Creating Missing Files...</h2>";

foreach($files as $file => $content) {
    // Create directory if it doesn\'t exist
    $dir = dirname($file);
    if(!is_dir($dir)) {
        mkdir($dir, 0777, true);
        echo "✓ Created directory: $dir<br>";
    }
    
    // Create file
    if(!file_exists($file)) {
        file_put_contents($file, $content);
        echo "✓ Created file: $file<br>";
    } else {
        echo "✓ File already exists: $file<br>";
    }
}

echo "<h3 style=\"color: green;\">✓ Setup completed!</h3>";
echo "<p><a href=\"index.php\">Go to Library System</a></p>";
?>