CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    isbn VARCHAR(20) UNIQUE NOT NULL,
    genre VARCHAR(100),
    publication_year INT,
    quantity INT DEFAULT 1,
    available INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO books (title, author, isbn, genre, publication_year, quantity, available) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', '9780743273565', 'Fiction', 1925, 3, 2),
('To Kill a Mockingbird', 'Harper Lee', '9780061120084', 'Fiction', 1960, 5, 3),
('1984', 'George Orwell', '9780451524935', 'Dystopian', 1949, 4, 4),
('Pride and Prejudice', 'Jane Austen', '9780141439518', 'Romance', 1813, 2, 1);