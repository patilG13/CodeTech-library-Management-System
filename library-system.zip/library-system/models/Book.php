<?php
class Book {
    // Database connection and table name
    private $conn;
    private $table_name = "books";

    // Object properties
    public $id;
    public $title;
    public $author;
    public $isbn;
    public $genre;
    public $publication_year;
    public $quantity;
    public $available;
    public $created_at;
    public $updated_at;

    // Constructor with $db as database connection
    public function __construct($db) {
        $this->conn = $db;
    }
    public function create() {
        try {
            // Validate input data
            $this->validate();
            
            // Check if ISBN already exists
            if ($this->isbnExists()) {
                throw new Exception("A book with ISBN {$this->isbn} already exists.");
            }

            // SQL query to insert new book
            $query = "INSERT INTO " . $this->table_name . " 
                     SET title = :title, 
                         author = :author, 
                         isbn = :isbn, 
                         genre = :genre, 
                         publication_year = :publication_year, 
                         quantity = :quantity, 
                         available = :quantity"; // Initially all copies are available

            // Prepare statement
            $stmt = $this->conn->prepare($query);

            // Sanitize inputs
            $this->title = $this->sanitizeInput($this->title);
            $this->author = $this->sanitizeInput($this->author);
            $this->isbn = preg_replace('/[^0-9X\-]/', '', $this->isbn); // Remove non-ISBN characters

            // Bind parameters
            $stmt->bindParam(":title", $this->title);
            $stmt->bindParam(":author", $this->author);
            $stmt->bindParam(":isbn", $this->isbn);
            $stmt->bindParam(":genre", $this->genre);
            $stmt->bindParam(":publication_year", $this->publication_year);
            $stmt->bindParam(":quantity", $this->quantity);

            // Execute query
            if ($stmt->execute()) {
                $this->id = $this->conn->lastInsertId();
                return true;
            }
            return false;

        } catch (Exception $e) {
            error_log("Book creation error: " . $e->getMessage());
            throw $e;
        }
    }
    public function read() {
        $query = "SELECT * FROM " . $this->table_name . " 
                 ORDER BY created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt;
    }
    public function readOne() {
        $query = "SELECT * FROM " . $this->table_name . " 
                 WHERE id = :id 
                 LIMIT 0,1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            // Set object properties from row data
            $this->title = $row['title'];
            $this->author = $row['author'];
            $this->isbn = $row['isbn'];
            $this->genre = $row['genre'];
            $this->publication_year = $row['publication_year'];
            $this->quantity = $row['quantity'];
            $this->available = $row['available'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        
        return false;
    }
    public function update() {
        try {
            // Validate input data
            $this->validate();
            
            // Check if ISBN exists for other books (excluding current book)
            if ($this->isbnExists($this->id)) {
                throw new Exception("A book with ISBN {$this->isbn} already exists.");
            }

            // Ensure available copies don't exceed quantity
            if ($this->available > $this->quantity) {
                $this->available = $this->quantity;
            }

            $query = "UPDATE " . $this->table_name . "
                     SET title = :title,
                         author = :author,
                         isbn = :isbn,
                         genre = :genre,
                         publication_year = :publication_year,
                         quantity = :quantity,
                         available = :available
                     WHERE id = :id";

            $stmt = $this->conn->prepare($query);

            // Sanitize inputs
            $this->title = $this->sanitizeInput($this->title);
            $this->author = $this->sanitizeInput($this->author);
            $this->isbn = preg_replace('/[^0-9X\-]/', '', $this->isbn);

            // Bind parameters
            $stmt->bindParam(":title", $this->title);
            $stmt->bindParam(":author", $this->author);
            $stmt->bindParam(":isbn", $this->isbn);
            $stmt->bindParam(":genre", $this->genre);
            $stmt->bindParam(":publication_year", $this->publication_year);
            $stmt->bindParam(":quantity", $this->quantity);
            $stmt->bindParam(":available", $this->available);
            $stmt->bindParam(":id", $this->id);

            return $stmt->execute();

        } catch (Exception $e) {
            error_log("Book update error: " . $e->getMessage());
            throw $e;
        }
    }
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        
        return $stmt->execute();
    }
    public function search($keywords) {
        $query = "SELECT * FROM " . $this->table_name . "
                 WHERE title LIKE :keywords 
                 OR author LIKE :keywords 
                 OR isbn LIKE :keywords 
                 OR genre LIKE :keywords
                 ORDER BY title ASC";

        $stmt = $this->conn->prepare($query);
        
        $keywords = "%" . $keywords . "%";
        $stmt->bindParam(":keywords", $keywords);
        
        $stmt->execute();
        
        return $stmt;
    }
    public function getRecent($limit = 5) {
        $query = "SELECT * FROM " . $this->table_name . "
                 ORDER BY created_at DESC
                 LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":limit", $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt;
    }
    public function getByGenre($genre) {
        $query = "SELECT * FROM " . $this->table_name . "
                 WHERE genre = :genre
                 ORDER BY title ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":genre", $genre);
        $stmt->execute();
        
        return $stmt;
    }
    public function borrow() {
        try {
            // Check if book is available
            if (!$this->isAvailable()) {
                throw new Exception("Book is not available for borrowing.");
            }
            
            // Update available copies (-1)
            $query = "UPDATE " . $this->table_name . " 
                     SET available = available - 1 
                     WHERE id = :id AND available > 0";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $this->id);
            
            $result = $stmt->execute();
            
            if ($result && $stmt->rowCount() > 0) {
                // Update current object's available count
                $this->available -= 1;
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Book borrow error: " . $e->getMessage());
            throw $e;
        }
    }
    public function returnBook() {
        try {
            // Check if we can return (available < quantity)
            $query = "SELECT available, quantity FROM " . $this->table_name . " 
                     WHERE id = :id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $this->id);
            $stmt->execute();
            
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$row || $row['available'] >= $row['quantity']) {
                throw new Exception("Cannot return book. All copies are already available.");
            }
            
            // Update available copies (+1)
            $query = "UPDATE " . $this->table_name . " 
                     SET available = available + 1 
                     WHERE id = :id AND available < quantity";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $this->id);
            
            $result = $stmt->execute();
            
            if ($result && $stmt->rowCount() > 0) {
                // Update current object's available count
                $this->available += 1;
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Book return error: " . $e->getMessage());
            throw $e;
        }
    }
    public function isAvailable() {
        $query = "SELECT available FROM " . $this->table_name . " 
                 WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return ($row && $row['available'] > 0);
    }
    public function isbnExists($exclude_id = null) {
        $query = "SELECT id FROM " . $this->table_name . " 
                 WHERE isbn = :isbn";
        
        if ($exclude_id) {
            $query .= " AND id != :exclude_id";
        }
        
        $query .= " LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":isbn", $this->isbn);
        
        if ($exclude_id) {
            $stmt->bindParam(":exclude_id", $exclude_id);
        }
        
        $stmt->execute();
        
        return $stmt->rowCount() > 0;
    }
    private function validate() {
        $errors = [];
        
        // Title validation
        if (empty(trim($this->title))) {
            $errors[] = "Title is required.";
        } elseif (strlen($this->title) > 255) {
            $errors[] = "Title cannot exceed 255 characters.";
        }
        
        // Author validation
        if (empty(trim($this->author))) {
            $errors[] = "Author is required.";
        } elseif (strlen($this->author) > 255) {
            $errors[] = "Author name cannot exceed 255 characters.";
        }
        
        // ISBN validation
        if (empty(trim($this->isbn))) {
            $errors[] = "ISBN is required.";
        } else {
            $clean_isbn = preg_replace('/[^0-9X]/', '', $this->isbn);
            if (!preg_match('/^(\d{9}[\dX]|\d{13})$/', $clean_isbn)) {
                $errors[] = "Invalid ISBN format. Use ISBN-10 (10 digits) or ISBN-13 (13 digits).";
            }
        }
        
        // Publication year validation
        $current_year = date('Y');
        if (!empty($this->publication_year)) {
            if ($this->publication_year < 1000 || $this->publication_year > $current_year) {
                $errors[] = "Publication year must be between 1000 and " . $current_year . ".";
            }
        }
        
        // Quantity validation
        if ($this->quantity < 1) {
            $errors[] = "Quantity must be at least 1.";
        }
        
        // Available validation (for updates)
        if (isset($this->available)) {
            if ($this->available < 0) {
                $errors[] = "Available copies cannot be negative.";
            }
            if ($this->available > $this->quantity) {
                $errors[] = "Available copies cannot exceed total quantity.";
            }
        }
        
        if (!empty($errors)) {
            throw new Exception(implode(" ", $errors));
        }
        
        return true;
    }
    private function sanitizeInput($input) {
        return htmlspecialchars(strip_tags(trim($input)));
    }
    public function getStatistics() {
        $query = "SELECT 
                    COUNT(*) as total_books,
                    SUM(quantity) as total_copies,
                    SUM(available) as available_copies,
                    (SUM(quantity) - SUM(available)) as borrowed_copies
                  FROM " . $this->table_name;
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function getGenres() {
        $query = "SELECT DISTINCT genre FROM " . $this->table_name . "
                 WHERE genre IS NOT NULL AND genre != ''
                 ORDER BY genre ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    public function getLowStock($threshold = 2) {
        $query = "SELECT * FROM " . $this->table_name . "
                 WHERE available <= :threshold
                 ORDER BY available ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":threshold", $threshold, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt;
    }
    public static function formatISBN($isbn) {
        // Remove all non-digit and X characters
        $clean_isbn = preg_replace('/[^0-9X]/', '', $isbn);
        
        // Return empty string if ISBN is invalid
        if (empty($clean_isbn)) {
            return $isbn; // Return original if empty
        }
        
        $length = strlen($clean_isbn);
        
        // Format ISBN-10 (10 characters)
        if ($length == 10) {
            return substr($clean_isbn, 0, 1) . '-' . 
                   substr($clean_isbn, 1, 3) . '-' . 
                   substr($clean_isbn, 4, 5) . '-' . 
                   substr($clean_isbn, 9, 1);
        }
        
        // Format ISBN-13 (13 characters)
        if ($length == 13) {
            return substr($clean_isbn, 0, 3) . '-' . 
                   substr($clean_isbn, 3, 1) . '-' . 
                   substr($clean_isbn, 4, 4) . '-' . 
                   substr($clean_isbn, 8, 4) . '-' . 
                   substr($clean_isbn, 12, 1);
        }
        
        // Return original if not standard length
        return $isbn;
    }
    public static function validateISBN($isbn) {
        $isbn = preg_replace('/[^0-9X]/', '', $isbn);
        
        // ISBN-10 validation
        if (strlen($isbn) == 10) {
            $sum = 0;
            for ($i = 0; $i < 9; $i++) {
                $sum += (10 - $i) * intval($isbn[$i]);
            }
            $check_digit = strtoupper($isbn[9]);
            $sum += ($check_digit == 'X') ? 10 : intval($check_digit);
            return ($sum % 11 == 0);
        }
        
        // ISBN-13 validation
        if (strlen($isbn) == 13) {
            $sum = 0;
            for ($i = 0; $i < 12; $i++) {
                $sum += ($i % 2 == 0) ? intval($isbn[$i]) : intval($isbn[$i]) * 3;
            }
            $check_digit = (10 - ($sum % 10)) % 10;
            return ($check_digit == intval($isbn[12]));
        }
        
        return false;
    }
    public function count() {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $row['total'];
    }
}
?>